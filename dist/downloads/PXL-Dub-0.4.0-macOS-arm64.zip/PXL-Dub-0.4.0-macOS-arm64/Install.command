#!/bin/bash
set -euo pipefail
PXL_PACKAGE_DIR="$(cd "$(dirname "$0")" && pwd)"
PXL_INSTALL_ROOT="${PXL_DUB_INSTALL_ROOT:-$HOME/Library/Audio/Plug-Ins}"
PXL_BACKUP_ROOT="${PXL_DUB_BACKUP_ROOT:-$HOME/Library/Application Support/Pixel Records/PXL Dub/Backups}"
PXL_STAMP="$(date +%Y%m%d-%H%M%S)-$$"
for PXL_FORMAT in AU VST3; do
    if [[ "$PXL_FORMAT" == AU ]]; then
        PXL_NAME="PXL Dub.component"
        PXL_DEST_DIR="$PXL_INSTALL_ROOT/Components"
    else
        PXL_NAME="PXL Dub.vst3"
        PXL_DEST_DIR="$PXL_INSTALL_ROOT/VST3"
    fi
    test -d "$PXL_PACKAGE_DIR/$PXL_FORMAT/$PXL_NAME"
    mkdir -p "$PXL_DEST_DIR"
    ditto "$PXL_PACKAGE_DIR/$PXL_FORMAT/$PXL_NAME" "$PXL_DEST_DIR/$PXL_NAME.new.$$"
    if [[ -e "$PXL_DEST_DIR/$PXL_NAME" ]]; then
        mkdir -p "$PXL_BACKUP_ROOT/$PXL_STAMP"
        mv "$PXL_DEST_DIR/$PXL_NAME" "$PXL_BACKUP_ROOT/$PXL_STAMP/$PXL_NAME"
    fi
    mv "$PXL_DEST_DIR/$PXL_NAME.new.$$" "$PXL_DEST_DIR/$PXL_NAME"
done
echo "PXL Dub AU and VST3 installed. Rescan plugins in your DAW, load PXL Dub and start the transport."
