# PXL Dub progress — plan: docs/superpowers/plans/2026-10-18-pxl-dub.md

User approved the design and explicitly instructed building PXL Dub. Execute inline through delivery; do not stop for a second planning approval.

Pre-flight: Task 2 consumes Task 1's instance en_* methods; Task 3 consumes only processor parameters and atomic UI state. Original C DSP is retained as a parity oracle. No shared mutable engine state is permitted in product code.

Implementation decisions and verification results will be recorded here as work completes.

Task 1: Engine generated and compiled; original DSP body arithmetic retained. Eight audible deterministic preset renders match upstream exactly with a second interleaved engine. Ping-loop recall passes. Upstream tests pass (11.39 seconds).

Task 2/3: Processor and editor implemented; Release native builds in progress. All audio controls use cached atomic parameter pointers, direct engine application on the audio thread and fixed 64-sample engine quanta. Output resampling uses a preallocated streaming cubic interpolator, with its two-engine-sample latency reported to the host.

Decision: original MIDI-output enable is omitted from the native parameter UI because this is an audio instrument without a MIDI output bus. Its upstream source is preserved.

Task 2: complete. ProcessorTests passes all rates/block sizes, internal/host transport, seeks, BPM range, state/pattern recall, preset switches and zero C++ audio-callback allocations.

Task 3: complete. Five-tab editor implemented, captured and inspected. Drum layout adjusted to fit all chance values; editor recreation succeeds. Momentary controls clear on release/close/restore.

Final review: fresh reviewer examined complete native port. Four P2 findings fixed: pending restored loops saved before audio; Mode/Piece semantics; musical loops lost on Panic/re-prepare; short host seeks hidden by buffer-size tolerance. Suspended-save and Panic regressions reproduced RED before fixes; full suite GREEN after all fixes. Mode uses zero custom mask to follow the mode; explicit custom masks override it. Piece is saved metadata and host program selection, not an automation control.

Final verification: Release build succeeds; 4/4 CTest suites pass (11.21 s). Actual AU wrapper loads/renders/recalls state/retains tails/reaches silence. Final VST3 pluginval strictness 5 succeeds. 24-second stereo 48 kHz / 24-bit WAV rendered from actual processor. Packaging and installer smoke test follow.

Task 4: complete. Package built with AU/VST3, installer, screenshot, demo, evidence and corresponding source including JUCE. Both packaged bundles pass strict signature verification. Installer was run twice in a generated temporary directory: install, backup and replacement all passed. ZIP integrity and packaged Source equality passed. Manual DAW audition remains an explicit limit, not a claimed validation result.

Installation follow-up: user authorized installation to their plugin folders. AU/VST3 were installed to ~/Library/Audio/Plug-Ins, signatures verified. System auval exposed unsupported MIDI entry points: JUCE selected AUBaseFactory because NEEDS_MIDI_INPUT was false, although the component is an aumu instrument. Added real AU MIDI and MIDIEventList regression calls; observed RED with -4. Enabled/consumed incoming host MIDI to select JUCE's AUMusicDeviceFactory, while retaining generative behavior. Rebuild, replacement install and validation follow.

Installed fixed AU and VST3 to /Users/thecore/Library/Audio/Plug-Ins/{Components,VST3}, retaining backups of the previous copies. Strict signatures pass on both installed bundles. System AU validation now succeeds, including MIDI tests; real AU wrapper regression is GREEN. Re-running the complete suite and installed VST3 validation before refreshing the source/package evidence.

2126 redesign follow-up (user approved visual concept and authorized installed AU/VST3 updates): native vector theme implemented with dark ceramic rails, spectral rotary arcs, calibrated ticks, monospaced labels, module-specific signal glyphs and interference linework. Next chord, New pattern and Panic moved to a safe asynchronous header menu. A live output trace uses atomic snapshots of existing engine scope data, without changing sound generation or parameter/state identifiers.

EditorTests added: observed RED for missing action menu before implementation; GREEN after implementation for menu/scope, five pages, direct control bounds at 1040x760 / 1100x760 / 1500x1000, and editor recreation preserving parameters. ProcessorTests covers finite, nonzero live trace data and retains the existing allocation-free callback checks. Real editor screenshots reviewed on Play, Voices and Drums. Full 0.2.0 build and final review in progress.

2126 follow-up complete: 0.2.0 Release built; all five CTest suites pass (10.96 s). Fresh review's chord-quality finding fixed by reusing upstream en_chord_name with diminished/augmented/suspended/minor-seventh regressions. All five native pages captured and inspected. Installed AU passes auval; installed VST3 passes pluginval strictness 5; both installed versions and signatures verified. 24-second PCM demo matches pre-redesign audio exactly. Prior installed bundles backed up; source/state identifiers preserved. Updated package and screenshot being saved.

## 0.3.0 — living glyphs and kick sidechain (2026-10-18)

User requested sound-reactive per-module graphics and kick-controlled ducking of other channels. Passive generated DSP taps observe isolated stabs/bass/pings/drums and wet returns; the message-thread motion eases small glyph deformations/brightness and settles at silence. Main and Voices pages map to their own actual buses. Upstream C remains untouched and vanilla generated-engine renders retain exact oracle parity.

Existing Duck depth is retained. Native full-bus ducking now includes vinyl, avoids new triggers when Drums is zero, preserves the full kick, and adds an appended automatable duck_release (20–800 ms, default130) plus compact peak-gain-reduction display. No external sidechain bus is added. New meter/motion tests were observed failing before implementation; duck tests cover music/vinyl, untouched kick, wet returns/non-kick drums, release and mute/zero-level triggers. Processor state regression confirms new recovery recall and old sessions loading130 even into an edited instance. A read-only reviewer found no material issue, confirmed bus mapping, bounded fixed storage and state migration; shared master effects make per-bus magnitudes approximate contributions, appropriate for subtle graphics. Release verification/install pending.

0.3.0 final: additional heartbeat regression observed RED before implementation, GREEN after. Graphics expire stale audio activity when a host suspends callbacks and resume with new blocks. Final Release and all8 CTest suites passed (11.08s); actual glyph pixel isolation checks passed. Fresh native capture inspected. AU/VST3 installed with0.2.0 backups; both installed versions/signatures verified. Refreshed per-user AU registrar's cached version, then auval identified0.3.0 and succeeded. Installed VST3 pluginval strictness5 identified0.3.0 and succeeded. Fresh24-second PCM demo rendered. Read-only follow-up review found no material issue. Full corresponding-source delivery archive saved as dist/PXL-Dub-0.3.0-macOS-arm64.zip.
