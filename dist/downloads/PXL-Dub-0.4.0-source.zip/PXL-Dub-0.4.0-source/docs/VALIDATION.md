# PXL Dub 0.4.0 — individual pumping and web instrument

2026-10-18. Native arm64 AU/VST3, macOS12+, JUCE8.0.14. Web uses WASI SDK34 and a standalone WebAssembly module without runtime imports.

- Release build succeeds. Native CTest8/8 passes, zero failures,10.52s, including exact vanilla/upstream parity, isolated bus taps, full ducking behavior, transport/state/rates, allocation-free callbacks, AU factory rendering and six-page native editor verification.
- Ducking tests verify0% bypasses only its own bus,100% applies the full master depth, untouched kick, wet/other-drum/vinyl routing,5ms amount ramping, no triggers from silent/muted kicks, recovery timing, and no displayed reduction when all six amounts are zero.
- New APVTS parameters append to existing IDs/order: duck_chord, duck_pings, duck_bass, duck_percussion, duck_vinyl, duck_space;0–100/default100. State tests confirm individual recall and old sessions receiving100/default130ms recovery.
- A fresh24-second48kHz/24-bit stereo default render matches0.3.0 PCM exactly. The existing master depth/recovery sound is preserved at default layer amounts.
- Installed AU auval identifies Component Version0.4.0 (0x400) and succeeds including MIDI tests. Per-user AU registration was refreshed after stale0.3.0 metadata. Installed VST3 pluginval strictness5 identifies v0.4.0 and reports SUCCESS. Both installed bundles pass strict signature verification. Old bundles are backed up automatically.
- Browser engine raw PCM matches the native bridge exactly. An initial mismatch exposed automatic linker constructor wrappers resetting the RNG on each export; explicitly exporting __wasm_call_ctors removed those wrappers. No WASI imports are present.
- Node tests verify finite audible worklet output and stable tempo at44.1/48/96kHz, Panic clearing buffered audio, chord-quality labels, and patch recall with six duck amounts and82 generated-loop bytes. Bad versions, malformed/oversized inputs and denied storage are handled.
- Actual Chromium browser checks measure finite, nonzero analyser samples at44.1kHz. Local save/reload preserves duck amounts and loops without auto-starting audio. Run after context suspension was reproduced failing, fixed and verified running. Panic, malformed imports and keyboard amount control pass.
- All six web pages have no viewport overflow at390px and1100px. Desktop/mobile screenshots inspected. Sound-reactive glyphs follow the proper layer buses and settle on stale telemetry; UI waveform reads actual audio scope samples.
- Native/editor screenshots captured. The same approved minimal2126 direction carries through the playable page and download section.

Native builds are ad-hoc signed, not notarized. Browser verification used automated Chromium, not a manual Safari/Firefox/mobile-device audition. Musical/artistic acceptance and manual DAW audition remain user review steps. Restart the DAW or reload the plugin binary to use installed0.4.0.

Download/source archive build verification and public deployment results are recorded in docs/progress.md. Prior validation records are in validation/0.1.0.md,0.2.0.md and0.3.0.md.
