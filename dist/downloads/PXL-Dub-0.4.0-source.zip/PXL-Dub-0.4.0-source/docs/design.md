# PXL Dub — proposed native instrument

Date: 2026-10-18. Status: approved by the user; implemented as PXL Dub 0.1.0.

## Intent

Create a new native AU and VST3 instrument from DUB-1. The user selected native
AU/VST3. Working name PXL Dub follows the existing PXL Seq project in this workspace.
Preserve DUB-1's generative musical behavior and sound engine while providing a
compact DAW interface. Conventional keyboard-played polyphony is a separate
extension, not assumed by this clone.

## Source and approach

Upstream clone: `FM1-DUB-Upstream`, commit
`0945f5ba447ba9f836ac4759e4ebcb7772e47c16`.

Recommended: port the original C DSP into an independently owned engine per plugin
instance, with JUCE providing the AU/VST3 wrappers, parameters, state and interface.
Reuse the existing local JUCE installation and build conventions. Put new product
code in a separate `PXLDub` directory; leave PXL Seq untouched.

Alternatives: a new DSP implementation would allow more redesign but lose immediate
source fidelity; embedding the web emulator would preserve its UI but add a browser
runtime and complicate host integration. Neither is preferred for a native clone.

Preserve upstream GPL-3.0-only licensing and attribution; include corresponding
source and third-party notices with any distributable package.

## Instrument and controls

Retain the eight original pieces, chord voices, FM pings, bass voices, drum kits,
generative arrangement, custom scale, eight chord slots, five drum pattern lanes,
sound/FM controls, echo, reverb, cloud, crackle and performance effects.

The primary panel shows preset, Run, Sync, root/scale, layer levels, cutoff, decay,
echo, feedback, reverb, motion and dub hold. Secondary tabs expose sound editing,
chords, drum patterns and performance effects. Display the current chord, arrangement
position and activity without recreating the hardware's button navigation.

The default plugin runs when the DAW transport runs. An internal-clock mode allows
manual playback while the host is stopped. Stop releases generation and allows
effect tails; Panic clears all sound. Host sync overrides preset tempo without
overwriting its stored internal tempo. New plugin identifiers prevent collisions
with PXL Seq or upstream products.

## Engine and host integration

The current DSP has global mutable state and a fixed 44.1 kHz rate. Move mutable
state into each engine instance, retaining arithmetic and processing order. Keep
44.1 kHz as the engine rate for the initial port and resample its stereo output to
the host rate with preallocated streaming buffers. Account for resampler latency.

Deliver host clock events at the appropriate engine sample positions. Define
start/restart/seek as a fresh phrase; preserve tails on ordinary stop. Test tempo
changes and block boundaries. Separate stored parameter values from momentary
performance commands. Apply controls on the audio thread, with bounded command
handling and no audio-thread allocation, filesystem access or blocking locks.

Use stable parameter IDs and versioned state. Save all editable values, selected
piece, scale, user patterns and ping loops. Recall musical settings, not in-flight
echo/reverb buffers. Expose appropriate controls to host automation. Snapshot UI
activity safely rather than reading engine state concurrently.

## Verification and delivery

Run the upstream DSP tests as a baseline. Compare deterministic upstream and
ported renders at 44.1 kHz using identical seeds and command timing. Test independent
instances, preset/state recall, host start/stop/seek, tempo changes, automation,
variable block sizes and 44.1/48/96 kHz output. Check finite audio and effect tails.

Build AU and VST3, run available AU/plugin validators, and provide local packages,
build instructions, source attribution and a short listening render. Distinguish
validator success from actual DAW audition and artistic acceptance. Installation
and public release are separate from preparing local build artifacts.
