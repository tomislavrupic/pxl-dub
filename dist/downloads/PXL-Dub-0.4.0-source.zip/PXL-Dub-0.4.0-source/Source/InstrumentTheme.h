#pragma once
#include <juce_audio_utils/juce_audio_utils.h>
#include "SignalMotion.h"

namespace dubui {
inline const juce::Colour background{0xff0c0e13}, panel{0xff12151c}, edge{0xff303640};
inline const juce::Colour ink{0xffe2e5ed}, muted{0xff8993a3}, accent{0xffc9e8a0};
inline const juce::Colour cyan{0xff84d7d4}, violet{0xffa999e1}, rose{0xffc493ba};
inline juce::Font font(float size) { return juce::Font{juce::FontOptions("Menlo",size,juce::Font::plain)}; }
inline void text(juce::Graphics& g,const juce::String& s,juce::Rectangle<int> r,float size,
                 juce::Colour colour=ink,juce::Justification align=juce::Justification::centredLeft) {
    g.setColour(colour);g.setFont(font(size));g.drawText(s,r,align,false);
}
inline juce::ColourGradient spectrum(juce::Rectangle<float> r) {
    juce::ColourGradient grad(accent,r.getBottomLeft(),rose,r.getTopRight(),false);
    grad.addColour(.34,cyan);grad.addColour(.69,violet);return grad;
}
inline void screw(juce::Graphics& g,juce::Point<float> c) {
    g.setColour(edge.brighter(.25f));g.drawEllipse(c.x-3.4f,c.y-3.4f,6.8f,6.8f,.7f);
    g.setColour(muted.withAlpha(.5f));g.drawLine(c.x-1.7f,c.y+.8f,c.x+1.7f,c.y-.8f,.7f);
}
inline void module(juce::Graphics& g,juce::Rectangle<int> r,const juce::String& title,int index,const SignalMotion& motion={}) {
    const juce::Colour colours[]{accent,cyan,violet,rose};const auto colour=colours[index%4];
    auto b=r.toFloat();g.setGradientFill(juce::ColourGradient(panel,b.getTopLeft(),background,b.getBottomRight(),false));
    g.fillRoundedRectangle(b,3);g.setColour(edge);g.drawRoundedRectangle(b.reduced(.5f),3,.7f);
    text(g,juce::String(index+1).paddedLeft('0',2),r.withTrimmedLeft(16).withTrimmedTop(10).withHeight(20),9,muted.darker(.25f));
    text(g,title,r.withTrimmedLeft(45).withTrimmedTop(10).withHeight(20),11,ink);
    g.setColour(colour.withAlpha(.45f+.55f*motion.amount));g.fillEllipse(b.getRight()-20,b.getY()+18,3.5f,3.5f);
    g.setColour(edge);g.drawHorizontalLine(r.getY()+36,b.getX()+16,b.getRight()-16);
    // Etched, module-specific signal glyphs, intentionally separate from the controls.
    const float x=b.getX()+18,y=b.getBottom()-20;
    const float flex=motion.amount*2.4f, wave=std::sin(motion.phase)*flex;
    g.setColour(colour.withAlpha(.35f+.32f*motion.amount));
    if(index%4==0) {
        for(int i=0;i<4;++i){juce::Path p;p.startNewSubPath(x,y-5+i*3);p.cubicTo(x+14,y-5+i*3+wave,x+18,y+flex*(i-1.5f)*.5f,x+34,y);g.strokePath(p,juce::PathStrokeType(.6f));}
    } else if(index%4==1) {
        for(int i=0;i<4;++i)g.drawEllipse(x+i*5-wave*.35f,y-5-flex*.35f,16+wave*.7f,10+flex*.7f,.55f);
    } else if(index%4==2) {
        juce::Path p;for(int i=0;i<=90;++i){float t=juce::MathConstants<float>::twoPi*i/90;auto pt=juce::Point<float>{x+17+16*std::sin(3*t+wave*.14f),y+(6+flex*.45f)*std::sin(4*t)};if(i==0)p.startNewSubPath(pt);else p.lineTo(pt);}g.strokePath(p,juce::PathStrokeType(.5f));
    } else {
        for(int i=0;i<4;++i){juce::Path p;p.startNewSubPath(x+i*8,y+5);p.quadraticTo(x+i*8+4,y-8-flex*(.5f+.5f*std::sin(motion.phase-i*.6f)),x+i*8+8,y+5);g.strokePath(p,juce::PathStrokeType(.6f));}
    }
    text(g,"BUS / "+juce::String(index+1).paddedLeft('0',2),{r.getRight()-92,r.getBottom()-30,76,20},8,muted.darker(.3f),juce::Justification::centredRight);
}
inline void interference(juce::Graphics& g,juce::Rectangle<float> r) {
    g.setGradientFill(spectrum(r));
    for(int k=0;k<12;++k) {
        juce::Path p;
        for(int i=0;i<=220;++i) {
            const float t=i/220.f,envelope=std::pow(std::sin(juce::MathConstants<float>::pi*t),2.f);
            auto pt=juce::Point<float>{r.getX()+r.getWidth()*t,r.getCentreY()+envelope*(4.f*std::sin(i*.048f+k*.24f)+k*.42f-2.5f)};
            if(i==0)p.startNewSubPath(pt);else p.lineTo(pt);
        }
        g.saveState();g.setOpacity(.22f);g.strokePath(p,juce::PathStrokeType(.45f));g.restoreState();
    }
}
struct Look final : juce::LookAndFeel_V4 {
    Look() {
        setColour(juce::Label::textColourId,ink);setColour(juce::Slider::textBoxTextColourId,ink);
        setColour(juce::Slider::textBoxOutlineColourId,juce::Colours::transparentBlack);
        setColour(juce::Slider::textBoxBackgroundColourId,juce::Colours::transparentBlack);
        setColour(juce::Slider::trackColourId,accent);setColour(juce::Slider::thumbColourId,ink);
        setColour(juce::ComboBox::backgroundColourId,panel);setColour(juce::ComboBox::textColourId,ink);setColour(juce::ComboBox::outlineColourId,edge);
        setColour(juce::PopupMenu::backgroundColourId,panel);setColour(juce::PopupMenu::textColourId,ink);
        setColour(juce::PopupMenu::highlightedBackgroundColourId,edge);setColour(juce::PopupMenu::highlightedTextColourId,accent);
        setColour(juce::TextButton::buttonColourId,panel);setColour(juce::TextButton::buttonOnColourId,accent);
        setColour(juce::TextButton::textColourOffId,muted);setColour(juce::TextButton::textColourOnId,ink);
    }
    juce::Font getLabelFont(juce::Label& label) override { return font(label.getFont().getHeight()); }
    juce::Font getComboBoxFont(juce::ComboBox&) override { return font(11); }
    juce::Font getPopupMenuFont() override { return font(12); }
    juce::Label* createSliderTextBox(juce::Slider& slider) override {
        auto* label=juce::LookAndFeel_V4::createSliderTextBox(slider);label->setFont(font(14));return label;
    }
    void drawRotarySlider(juce::Graphics& g,int x,int y,int w,int h,float value,float start,float end,juce::Slider& slider) override {
        auto area=juce::Rectangle<float>((float)x,(float)y,(float)w,(float)h);
        const float radius=juce::jmin(area.getWidth(),area.getHeight())*.5f-7.f;const auto c=area.getCentre();
        if(radius<7)return;
        const float angle=start+value*(end-start);
        auto point=[&](float a,float r){return juce::Point<float>{c.x+std::sin(a)*r,c.y-std::cos(a)*r};};
        for(int i=0;i<=20;++i) {
            const auto a=start+(end-start)*i/20.f;
            g.setColour(i%5==0?muted.withAlpha(.65f):edge.brighter(.15f));
            g.drawLine({point(a,radius+4),point(a,radius+(i%5==0?7.f:5.5f))},.65f);
        }
        juce::Path track,fill;track.addCentredArc(c.x,c.y,radius,radius,0,start,end,true);
        fill.addCentredArc(c.x,c.y,radius,radius,0,start,angle,true);
        g.setColour(edge.darker(.2f));g.strokePath(track,juce::PathStrokeType(2));
        g.setGradientFill(spectrum(area));g.strokePath(fill,juce::PathStrokeType(slider.isMouseOverOrDragging()?2.8f:2.2f));
        const float body=radius-5;
        g.setGradientFill(juce::ColourGradient(juce::Colour(0xff303641),c.x-body*.5f,c.y-body,juce::Colour(0xff141921),c.x+body*.6f,c.y+body,false));
        g.fillEllipse(c.x-body,c.y-body,body*2,body*2);
        g.setColour(edge.brighter(.18f));g.drawEllipse(c.x-body,c.y-body,body*2,body*2,.65f);
        g.setColour(juce::Colour(0xff1b2029));g.drawEllipse(c.x-body+3,c.y-body+3,body*2-6,body*2-6,.5f);
        g.setColour(ink);g.drawLine({point(angle,body*.57f),point(angle,body*.85f)},1.8f);
        g.setColour(juce::Colour(0xff242a34));g.fillEllipse(c.x-1.5f,c.y-1.5f,3,3);
    }
    void drawButtonBackground(juce::Graphics& g,juce::Button& b,const juce::Colour&,bool over,bool down) override {
        const bool on=b.getToggleState()||down;auto r=b.getLocalBounds().toFloat().reduced(.5f);
        if(b.getProperties().getWithDefault("layer",false)) {
            if(over){g.setColour(panel);g.fillRoundedRectangle(r,3);}
            g.setColour(on?accent:edge);g.fillEllipse(2,r.getCentreY()-1.5f,3,3);return;
        }
        g.setColour(on?juce::Colour(0xff202820):(over?juce::Colour(0xff1b2028):panel));g.fillRoundedRectangle(r,3);
        g.setColour(on?accent.withAlpha(.55f):(over?muted:edge));g.drawRoundedRectangle(r,3,.8f);
        if(on && b.getWidth()>54){g.setColour(accent);g.fillEllipse(9,r.getCentreY()-1.5f,3,3);}
    }
    void drawButtonText(juce::Graphics& g,juce::TextButton& b,bool,bool down) override {
        if(b.getComponentID()=="instrument-menu") {g.setColour(muted);for(int i=0;i<3;++i)g.fillEllipse(b.getWidth()*.5f-1,9.f+i*5,2,2);return;}
        const bool layer=b.getProperties().getWithDefault("layer",false);
        text(g,b.getButtonText(),b.getLocalBounds().reduced(layer?9:2,0),b.getWidth()<40?10.f:(layer?9.f:10.5f),b.getToggleState()||down?ink:muted,juce::Justification::centred);
    }
    void drawComboBox(juce::Graphics& g,int w,int h,bool,int,int,int,int,juce::ComboBox&) override {
        g.setColour(panel);g.fillRoundedRectangle(.5f,.5f,w-1.f,h-1.f,3);
        g.setColour(edge);g.drawRoundedRectangle(.5f,.5f,w-1.f,h-1.f,3,.7f);
        juce::Path p;p.startNewSubPath(w-19.f,h*.5f-2);p.lineTo(w-15.f,h*.5f+2);p.lineTo(w-11.f,h*.5f-2);g.setColour(muted);g.strokePath(p,juce::PathStrokeType(.8f));
    }
    void positionComboBoxText(juce::ComboBox& b,juce::Label& label) override {label.setBounds(10,1,b.getWidth()-34,b.getHeight()-2);label.setFont(getComboBoxFont(b));}
    void drawLinearSlider(juce::Graphics& g,int x,int y,int w,int h,float pos,float,float,juce::Slider::SliderStyle,juce::Slider&) override {
        const float cy=y+h*.5f;g.setColour(edge);g.drawLine((float)x,cy,(float)(x+w),cy,1.5f);
        g.setGradientFill(spectrum({(float)x,(float)y,(float)w,(float)h}));g.drawLine((float)x,cy,pos,cy,1.5f);
        g.setColour(ink);g.fillEllipse(pos-2.8f,cy-2.8f,5.6f,5.6f);
    }
    int getTabButtonBestWidth(juce::TabBarButton& b,int) override {return 32+b.getButtonText().length()*9;}
    void drawTabButton(juce::TabBarButton& b,juce::Graphics& g,bool over,bool) override {
        auto r=b.getLocalBounds();const bool selected=b.getToggleState();
        text(g,b.getButtonText(),r.reduced(13,0),10.5f,selected?ink:(over?ink:muted));
        if(selected){g.setGradientFill(spectrum(r.toFloat()));g.fillRect(13,r.getBottom()-2,r.getWidth()-26,1);}
    }
};
}
