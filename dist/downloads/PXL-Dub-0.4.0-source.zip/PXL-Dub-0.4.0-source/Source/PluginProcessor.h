#pragma once
#include <juce_audio_utils/juce_audio_utils.h>
#include "Engine.h"
#include <array>
#include <atomic>
#include <memory>

class DubProcessor final : public juce::AudioProcessor {
    std::unique_ptr<pxldub::Engine> engine;
public:
    DubProcessor();
    ~DubProcessor() override;
    void prepareToPlay(double, int) override;
    void releaseResources() override {}
    void processBlock(juce::AudioBuffer<float>&, juce::MidiBuffer&) override;
    bool isBusesLayoutSupported(const BusesLayout& l) const override { return l.getMainOutputChannelSet() == juce::AudioChannelSet::stereo(); }
    const juce::String getName() const override { return "PXL Dub"; }
    bool acceptsMidi() const override { return true; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override { return 30.; }
    int getNumPrograms() override { return EN_NPIECES; }
    int getCurrentProgram() override { return currentPiece.load(); }
    void setCurrentProgram(int i) override { loadPiece(i); }
    const juce::String getProgramName(int i) override { return pxldub::pieceName(i); }
    void changeProgramName(int, const juce::String&) override {}
    bool hasEditor() const override { return true; }
    juce::AudioProcessorEditor* createEditor() override;
    void getStateInformation(juce::MemoryBlock&) override;
    void setStateInformation(const void*, int) override;
    static juce::String engineID(int index) { return "engine_" + juce::String(index); }
    inline static constexpr const char* duckIDs[]{"duck_chord","duck_pings","duck_bass","duck_percussion","duck_vinyl","duck_space"};
    float value(const juce::String&) const;
    void setValue(const juce::String&, float);
    int engineValue(int index) const;
    unsigned scaleMask() const;
    juce::String currentChordName() const;
    void setEngineValue(int index, int v) { setValue(engineID(index), (float)v); }
    void loadPiece(int index);
    void requestNext() { nextRequested.store(true); }
    void requestRegrow() { regrowRequested.store(true); }
    void requestPanic() { panicRequested.store(true); }
    void setPerformance(unsigned bits) { performance.store(bits); }
    void setEffects(unsigned bits) { effects.store(bits); }
    void clearMomentary() { performance.store(0); effects.store(0); }
    std::array<uint8_t, EN_PINGS_N> pingSnapshot() const;
    juce::AudioProcessorValueTreeState state;
    struct Activity {
        std::atomic<bool> running{false};
        std::atomic<int> steps{0}, root{5}, section{0}, phraseBar{0};
        std::array<std::atomic<int>, 4> chord{};
        std::array<std::atomic<float>, 9> levels{};
        std::array<std::atomic<float>, 128> scope{};
        // Chord, bass, pings, drums, wet returns, complete output.
        std::array<std::atomic<float>, 6> buses{};
        std::atomic<float> duckReduction{0};
        std::atomic<unsigned> visualSequence{0};
        std::atomic<float> peak{0}, tempo{122};
    } activity;
private:
    static juce::AudioProcessorValueTreeState::ParameterLayout createLayout();
    std::array<std::atomic<float>*, pxldub::P_NPARAMS> raw{};
    std::atomic<float>* syncControl{};
    std::atomic<float>* runControl{};
    std::atomic<float>* holdControl{};
    std::atomic<float>* scaleControl{};
    std::atomic<float>* muteControl{};
    std::atomic<float>* outputControl{};
    std::atomic<float>* duckReleaseControl{};
    std::array<std::atomic<float>*,6> layerDuckControls{};
    float appliedDuckRelease{-1};
    std::array<float,6> blockPeaks{}, meterEnvelopes{};
    float blockReduction{0}, reductionEnvelope{0};
    std::array<int, pxldub::P_NPARAMS> applied{};
    std::atomic<unsigned> transaction{0};
    std::atomic<int> currentPiece{0};
    std::atomic<bool> resetRequested{true}, nextRequested{false}, regrowRequested{false}, panicRequested{false};
    std::atomic<unsigned> performance{0}, effects{0};
    std::array<std::atomic<uint8_t>, EN_PINGS_N> savedPings{}, incomingPings{};
    std::atomic<unsigned> pingVersion{0}, incomingVersion{0};
    std::atomic<unsigned> publishedIncoming{0};
    std::atomic<bool> incomingEnabled{false};
    unsigned consumedIncoming{0};
    int appliedScale{-1}, appliedHold{-1}, appliedMutes{-1};
    unsigned appliedPerformance{0}, appliedEffects{0};
    double sampleRate{44100}, ratio{1}, clockTempo{122}, expectedPpq{0};
    bool wasPlaying{false}, wasSync{true}, hadPosition{false}, panicLatched{false};
    juce::LagrangeInterpolator leftResampler, rightResampler;
    std::array<float, 2048> sourceL{}, sourceR{};
    std::array<int32_t, 128> engineBuffer{};
    int available{0};
    bool hasRendered{false}, preservedPingsPending{false};
    std::array<uint8_t, EN_PINGS_N> preservedPings{};
    void applyControls();
    void renderSource(int required);
    void updateActivity();
    void hardReset();
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(DubProcessor)
};
