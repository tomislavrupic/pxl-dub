#include "PluginEditor.h"
using namespace pxldub;
#include "InstrumentTheme.h"
namespace {
using namespace dubui;
const char* notes[12]={"C","C#","D","Eb","E","F","F#","G","Ab","A","Bb","B"};
struct Knob : juce::Component {
    juce::Slider slider;juce::Label label;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> attachment;
    Knob(DubProcessor& p,int index,const juce::String& title={}) {
        addAndMakeVisible(label);addAndMakeVisible(slider);
        label.setText((title.isEmpty()?juce::String(parameterInfo(index).name):title).toUpperCase(),juce::dontSendNotification);label.setJustificationType(juce::Justification::centred);label.setFont(font(11.5f));
        slider.setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);slider.setTextBoxStyle(juce::Slider::TextBoxBelow,false,96,21);slider.setComponentID(DubProcessor::engineID(index));slider.setPopupDisplayEnabled(false,false,nullptr);
        slider.textFromValueFunction=[index](double v){char b[32]{};parameterText(index,(int)std::round(v),b);return juce::String(b);};
        slider.setDoubleClickReturnValue(true,parameterInfo(index).def);slider.setTooltip(parameterInfo(index).name);
        attachment=std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(p.state,DubProcessor::engineID(index),slider);
    }
    void resized() override {auto r=getLocalBounds();label.setBounds(r.removeFromTop(17));slider.setBounds(r);}
};
struct Recovery : juce::Component {
    juce::Slider slider;
    juce::AudioProcessorValueTreeState::SliderAttachment attachment;
    explicit Recovery(DubProcessor& p):attachment(p.state,"duck_release",slider) {
        setComponentID("kick-duck-recovery");
        addAndMakeVisible(slider);slider.setComponentID("duck_release");
        slider.setSliderStyle(juce::Slider::LinearHorizontal);slider.setTextBoxStyle(juce::Slider::TextBoxRight,false,53,18);
        slider.setTextValueSuffix(" ms");slider.setNumDecimalPlacesToDisplay(0);slider.setDoubleClickReturnValue(true,130);
        slider.setTooltip("Kick sidechain recovery, 20–800 ms. Duck sets the depth; the kick stays at full level.");
    }
    void paint(juce::Graphics& g)override{text(g,"RECOVERY",{0,0,68,getHeight()},8,muted);}
    void resized()override{slider.setBounds(getLocalBounds().withTrimmedLeft(70));}
};
struct GroupPage : juce::Component {
    struct Group {juce::String title;std::vector<std::unique_ptr<Knob>> knobs;juce::Rectangle<int> bounds;DubProcessor* processor{};int bus{};SignalMotion motion;};
    std::vector<Group> groups;
    std::unique_ptr<Recovery> recovery;
    SignalFeed feed;bool signalFresh{true};
    double lastMotionTime=juce::Time::getMillisecondCounterHiRes();
    void addGroup(DubProcessor& p,const juce::String& name,std::initializer_list<int> params,int bus) {
        Group group;group.title=name;group.processor=&p;group.bus=bus;
        for(int index:params){auto k=std::make_unique<Knob>(p,index);addAndMakeVisible(*k);group.knobs.push_back(std::move(k));}
        groups.push_back(std::move(group));
        if(name=="MIX"){recovery=std::make_unique<Recovery>(p);addAndMakeVisible(*recovery);}
    }
    void advance() {
        const auto now=juce::Time::getMillisecondCounterHiRes();const float dt=(float)((now-lastMotionTime)*.001);lastMotionTime=now;
        if(!groups.empty())signalFresh=feed.advance(groups[0].processor->activity.visualSequence.load(std::memory_order_relaxed),dt);
        for(auto& group:groups){auto& buses=group.processor->activity.buses;
            float level=group.bus==6?juce::jmax(buses[1].load(std::memory_order_relaxed),buses[2].load(std::memory_order_relaxed)):buses[group.bus].load(std::memory_order_relaxed);
            group.motion.advance(signalFresh?level:0.f,dt);
        }
    }
    void paint(juce::Graphics& g) override {
        for(size_t i=0;i<groups.size();++i)module(g,groups[i].bounds,groups[i].title,(int)i,groups[i].motion);
        if(recovery&&!groups.empty()){
            const auto r=groups[0].bounds;const float reduction=signalFresh?groups[0].processor->activity.duckReduction.load(std::memory_order_relaxed):0.f;
            g.setColour(edge);g.fillRect(r.getX()+62,r.getBottom()-21,27,2);
            g.setColour(cyan.withAlpha(.7f));g.fillRect((float)r.getX()+62,(float)r.getBottom()-21,27*juce::jlimit(0.f,1.f,reduction/.75f),2.f);
            text(g,juce::String(-juce::Decibels::gainToDecibels(juce::jmax(.001f,1.f-reduction)),1)+"dB",{r.getX()+91,r.getBottom()-29,53,18},8,muted);
        }
    }
    void resized() override {
        auto r=getLocalBounds().reduced(0,10);const int w=r.getWidth()/(int)groups.size();
        for(auto& group:groups) {
            group.bounds=r.removeFromLeft(w).reduced(5,0);auto area=group.bounds.reduced(12);
            area.removeFromTop(32);area.removeFromBottom(recovery&& &group==&groups[0]?52:22);
            if(recovery&& &group==&groups[0])recovery->setBounds(group.bounds.getX()+16,group.bounds.getBottom()-59,group.bounds.getWidth()-32,22);
            const int columns=group.knobs.size()>8?3:2;
            const int rows=((int)group.knobs.size()+columns-1)/columns;
            const int ch=area.getHeight()/rows;
            for(size_t i=0;i<group.knobs.size();++i)group.knobs[i]->setBounds(area.getX()+(int)(i%columns)*area.getWidth()/columns,area.getY()+(int)(i/columns)*ch,area.getWidth()/columns,ch);
        }
    }
};
struct AttachedCombo : juce::Component {
    juce::Label label;juce::ComboBox combo;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment> attachment;
    AttachedCombo(DubProcessor& p,int parameter,const juce::String& title,const juce::StringArray& items) {
        addAndMakeVisible(label);addAndMakeVisible(combo);label.setText(title,juce::dontSendNotification);label.setFont(font(10));label.setColour(juce::Label::textColourId,muted);
        combo.addItemList(items,1);attachment=std::make_unique<juce::AudioProcessorValueTreeState::ComboBoxAttachment>(p.state,DubProcessor::engineID(parameter),combo);
    }
    void resized() override {auto r=getLocalBounds();label.setBounds(r.removeFromTop(22));combo.setBounds(r);}
};
struct Chords : juce::Component {
    std::vector<std::unique_ptr<AttachedCombo>> combos;
    std::unique_ptr<AttachedCombo> playMode;
    Chords(DubProcessor& p) {
        juce::StringArray roots,kinds,types;
        for(auto* n:notes)roots.add(n);
        kinds={"Empty","Major","Minor","Sus 2","Sus 4","Diminished","Augmented"};types={"Triad","6","7","Maj 7","9","11","Add 9"};
        for(int slot=0;slot<8;++slot)for(int row=0;row<3;++row) {auto c=std::make_unique<AttachedCombo>(p,(row==0?P_CR0:row==1?P_CQ0:P_CX0)+slot,row==0?"ROOT":row==1?"KIND":"EXTENSION",row==0?roots:row==1?kinds:types);addAndMakeVisible(*c);combos.push_back(std::move(c));}
        playMode=std::make_unique<AttachedCombo>(p,P_PMODE,"PROGRESSION",juce::StringArray{"Random","In order"});addAndMakeVisible(*playMode);
    }
    void paint(juce::Graphics& g) override {text(g,"CHORD MEMORY",{20,12,300,25},14,accent);text(g,"Empty slots hold the previous chord. Drift sets the time between changes.",{20,44,getWidth()-40,24},13,muted);
        int w=(getWidth()-32)/8;for(int slot=0;slot<8;++slot){auto r=juce::Rectangle<int>(16+slot*w,86,w-8,278);g.setColour(panel);g.fillRoundedRectangle(r.toFloat(),7);text(g,juce::String(slot+1).paddedLeft('0',2),r.reduced(12).removeFromTop(25),17,accent);}}
    void resized() override {int w=(getWidth()-32)/8;for(int slot=0;slot<8;++slot)for(int row=0;row<3;++row)combos[slot*3+row]->setBounds(24+slot*w,124+row*64,w-24,54);playMode->setBounds(20,juce::jmin(366,getHeight()-66),220,54);}
};
struct DrumGrid : juce::Component, juce::SettableTooltipClient {
    DubProcessor& p;
    explicit DrumGrid(DubProcessor& processor):p(processor){setTooltip("Click a step to toggle its hit; Shift-click toggles its accent.");}
    void paint(juce::Graphics& g) override {
        const char* names[5]={"KICK","SHAKER","OPEN HAT","RIM","CLAP"};int cw=(getWidth()-100)/16;
        for(int d=0;d<5;++d){text(g,names[d],{0,24+d*30,92,26},11,muted);unsigned hits=(uint16_t)p.engineValue(P_DPAT0+d),acc=(uint16_t)p.engineValue(P_DACC0+d);
            for(int i=0;i<16;++i){auto r=juce::Rectangle<int>(100+i*cw+2,28+d*30,cw-5,20);bool on=hits>>i&1u;g.setColour(on?juce::Colour(0xff28372d):panel);g.fillRoundedRectangle(r.toFloat(),2);g.setColour(on?accent.withAlpha(.65f):edge);g.drawRoundedRectangle(r.toFloat().reduced(.5f),2,.7f);if(acc>>i&1u){g.setColour(accent);g.fillEllipse((float)r.getCentreX()-2,(float)r.getCentreY()-2,4,4);}if(d==0)text(g,juce::String(i+1),{r.getX(),0,r.getWidth(),20},10,muted,juce::Justification::centred);}
        }
    }
    void mouseDown(const juce::MouseEvent& e) override {int cw=(getWidth()-100)/16,d=(e.y-24)/30,i=(e.x-100)/cw;if(e.x<100||e.y<24||d<0||d>4||i<0||i>15)return;int index=(e.mods.isShiftDown()?P_DACC0:P_DPAT0)+d;auto bits=(uint16_t)p.engineValue(index);p.setEngineValue(index,(int16_t)(bits^(1u<<i)));repaint();}
};
struct Drums : juce::Component {
    DrumGrid grid;std::unique_ptr<AttachedCombo> kit,mode;std::vector<std::unique_ptr<Knob>> knobs;
    explicit Drums(DubProcessor& p):grid(p) {
        addAndMakeVisible(grid);juce::StringArray kits;for(int i=0;i<5;++i)kits.add(voiceName(3,i));
        kit=std::make_unique<AttachedCombo>(p,P_KIT,"KIT",kits);mode=std::make_unique<AttachedCombo>(p,P_DMODE,"PATTERN",juce::StringArray{"Generative","Custom"});addAndMakeVisible(*kit);addAndMakeVisible(*mode);
        for(int index:{P_KTUNE,P_KLEN,P_KPUNCH,P_HTONE,P_HATS,P_SWING,P_HITS,P_DACCENT,P_DCH0,P_DCH1,P_DCH2,P_DCH3,P_DCH4}){auto k=std::make_unique<Knob>(p,index);addAndMakeVisible(*k);knobs.push_back(std::move(k));}
    }
    void paint(juce::Graphics& g) override {text(g,"FIVE LANES / SIXTEEN STEPS",{16,53,400,22},10,cyan);text(g,"Click: hit   Shift-click: accent   Custom plays the edited pattern",{16,75,getWidth()-32,18},9,muted);}
    void resized() override {
        kit->setBounds(16,2,190,46);mode->setBounds(224,2,190,46);
        grid.setBounds(16,96,getWidth()-32,172);
        const int w=(getWidth()-32)/8,ch=(getHeight()-272)/2;
        for(size_t i=0;i<knobs.size();++i)knobs[i]->setBounds(16+(int)(i%8)*w,272+(int)(i/8)*ch,w,ch);
    }
};
struct Perform : juce::Component {
    DubProcessor& p;std::vector<std::unique_ptr<juce::TextButton>> moves,fx;
    Perform(DubProcessor& proc):p(proc) {
        for(const char* title:{"THROW","OPEN","SHUT","DROP","PUSH ECHO"}) {auto b=std::make_unique<juce::TextButton>(title);auto* button=b.get();button->onStateChange=[this]{update();};addAndMakeVisible(*button);moves.push_back(std::move(b));}
        for(int i=0;i<16;++i){auto b=std::make_unique<juce::TextButton>(effectName(i));b->onStateChange=[this]{update();};addAndMakeVisible(*b);fx.push_back(std::move(b));}
    }
    ~Perform() override {p.clearMomentary();}
    void update(){unsigned a=0,b=0;for(size_t i=0;i<moves.size();++i)if(moves[i]->isDown())a|=1u<<i;for(size_t i=0;i<fx.size();++i)if(fx[i]->isDown())b|=1u<<i;p.setPerformance(a);p.setEffects(b);}
    void paint(juce::Graphics& g) override {text(g,"DUB MOVES",{16,10,300,22},11,accent);text(g,"Hold to perform. Release to return.",{16,34,500,18},10,muted);text(g,"EFFECTS GRID",{16,138,300,22},11,violet);interference(g,{440.f,14.f,(float)getWidth()-470,28.f});}
    void resized() override {int w=(getWidth()-32)/5;for(size_t i=0;i<moves.size();++i)moves[i]->setBounds(16+(int)i*w,68,w-12,52);w=(getWidth()-32)/4;int h=(getHeight()-178)/4;for(size_t i=0;i<fx.size();++i)fx[i]->setBounds(16+(int)(i%4)*w,178+(int)(i/4)*h,w-12,h-10);}
};
struct OutputTrace final : juce::Component {
    DubProcessor& processor;
    explicit OutputTrace(DubProcessor& p):processor(p){setComponentID("output-scope");setInterceptsMouseClicks(false,false);}
    void paint(juce::Graphics& g) override {
        auto b=getLocalBounds().toFloat();g.setColour(background.darker(.15f));g.fillRoundedRectangle(b,2);g.setColour(edge);g.drawRoundedRectangle(b.reduced(.5f),2,.7f);
        text(g,"OUTPUT",{12,0,72,getHeight()},8,muted);
        auto trace=b.withTrimmedLeft(85).withTrimmedRight(310);const float gain=juce::Decibels::decibelsToGain(processor.value("output"));
        float peak=.025f;for(auto& value:processor.activity.scope)peak=juce::jmax(peak,std::abs(value.load(std::memory_order_relaxed)*gain));
        const float displayGain=juce::jlimit(1.f,16.f,.75f/peak);
        juce::Path path;
        for(size_t i=0;i<processor.activity.scope.size();++i){float sample=processor.activity.scope[i].load(std::memory_order_relaxed);auto pt=juce::Point<float>{trace.getX()+trace.getWidth()*i/(processor.activity.scope.size()-1),trace.getCentreY()-juce::jlimit(-1.f,1.f,sample*gain*displayGain)*trace.getHeight()*.42f};if(i==0)path.startNewSubPath(pt);else path.lineTo(pt);}
        g.setGradientFill(spectrum(trace));g.strokePath(path,juce::PathStrokeType(.85f));
        text(g,"MASTER",{getWidth()-278,0,70,getHeight()},8,muted);
    }
};
struct Ducking : juce::Component {
    std::array<juce::Slider,6> amounts;std::array<juce::Label,6> names;
    std::array<std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment>,6> attachments;
    Knob master;Recovery recovery;
    explicit Ducking(DubProcessor& p):master(p,P_DUCK,"MASTER DUCK"),recovery(p) {
        addAndMakeVisible(master);addAndMakeVisible(recovery);
        const char* titles[]{"CHORD","PINGS","BASS","PERCUSSION","VINYL","SPACE"};
        for(int i=0;i<6;++i){auto& s=amounts[i];auto& label=names[i];addAndMakeVisible(s);addAndMakeVisible(label);
            label.setText(titles[i],juce::dontSendNotification);label.setFont(font(11));label.setJustificationType(juce::Justification::centred);
            s.setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);s.setTextBoxStyle(juce::Slider::TextBoxBelow,false,90,21);
            s.setComponentID(DubProcessor::duckIDs[i]);s.setTextValueSuffix(" %");s.setNumDecimalPlacesToDisplay(0);s.setDoubleClickReturnValue(true,100);
            s.setTooltip("Kick duck amount: 0% leaves this layer steady; 100% applies the full master depth.");
            attachments[i]=std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(p.state,DubProcessor::duckIDs[i],s);
        }
    }
    void paint(juce::Graphics& g)override{text(g,"KICK → LAYERS",{20,8,300,25},12,cyan);text(g,"Choose how much each layer pumps. The kick stays full.",{20,36,getWidth()-40,20},10,muted);}
    void resized()override {
        auto r=getLocalBounds();const int left=180;master.setBounds(22,86,136,170);recovery.setBounds(18,286,160,24);
        const int w=(r.getWidth()-left-20)/3,h=(r.getHeight()-80)/2;
        for(int i=0;i<6;++i){const int x=left+(i%3)*w,y=80+(i/3)*h;names[i].setBounds(x,y,w,20);amounts[i].setBounds(x+18,y+22,w-36,h-27);}
    }
};
}

struct DubEditor::Impl {
    dubui::Look look;DubProcessor& p;OutputTrace trace;
    juce::ComboBox piece,root,scaleMode;juce::TextButton run{"RUN"},sync{"SYNC"},hold{"DUB HOLD"},menu;
    juce::Slider output;juce::TabbedComponent tabs{juce::TabbedButtonBar::TabsAtTop};
    std::array<juce::TextButton,12> scale;std::array<juce::TextButton,5> mutes;
    std::vector<std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment>> buttons;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> outputAttachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment> rootAttachment;
    bool refreshing=false;
    Impl(DubEditor& editor,DubProcessor& proc):p(proc),trace(proc) {
        editor.setLookAndFeel(&look);
        for(auto* c:std::initializer_list<juce::Component*>{&piece,&root,&scaleMode,&run,&sync,&hold,&menu,&trace,&output,&tabs})editor.addAndMakeVisible(*c);
        for(int i=0;i<8;++i)piece.addItem(juce::String(i+1).paddedLeft('0',2)+" / "+juce::String(pieceName(i)).toUpperCase(),i+1);
        piece.onChange=[this]{if(!refreshing)p.loadPiece(piece.getSelectedId()-1);};
        juce::StringArray modes;for(int i=0;i<8;++i)modes.add(modeName(i));modes.add("Custom");scaleMode.addItemList(modes,1);
        scaleMode.onChange=[this]{if(!refreshing){int m=scaleMode.getSelectedId()-1;if(m<8){p.setEngineValue(P_MODE,m);p.setValue("scale",0);}else p.setValue("scale",(float)p.scaleMask());}};
        for(int i=0;i<12;++i)root.addItem(notes[i],i+1);
        rootAttachment=std::make_unique<juce::AudioProcessorValueTreeState::ComboBoxAttachment>(p.state,DubProcessor::engineID(P_ROOT),root);
        for(auto pair:{std::pair<juce::TextButton*,const char*>{&run,"run"},{&sync,"sync"},{&hold,"hold"}}){pair.first->setClickingTogglesState(true);buttons.push_back(std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>(p.state,pair.second,*pair.first));}
        menu.setComponentID("instrument-menu");menu.setButtonText("...");menu.setTooltip("Instrument actions: next chord, new pattern, panic");
        menu.onClick=[this,&editor]{juce::PopupMenu actions;actions.addItem(1,"Next chord");actions.addItem(2,"New pattern");actions.addSeparator();actions.addItem(3,"Panic / clear sound");actions.showMenuAsync(juce::PopupMenu::Options().withTargetComponent(&menu),[safe=juce::Component::SafePointer<DubEditor>(&editor)](int action){if(auto* e=safe.getComponent()){if(action==1)e->processor.requestNext();else if(action==2)e->processor.requestRegrow();else if(action==3)e->processor.requestPanic();}});};
        output.setSliderStyle(juce::Slider::LinearHorizontal);output.setTextBoxStyle(juce::Slider::TextBoxRight,false,62,20);output.setTextValueSuffix(" dB");outputAttachment=std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(p.state,"output",output);
        output.setColour(juce::Slider::trackColourId,accent);output.setColour(juce::Slider::thumbColourId,ink);
        for(int i=0;i<12;++i){editor.addAndMakeVisible(scale[i]);scale[i].setButtonText(notes[i]);scale[i].onClick=[this,i]{unsigned mask=p.scaleMask();p.setValue("scale",(float)((mask^(1u<<i))|1u));};}
        const char* layers[5]={"CHORD","PINGS","BASS","KICK","HATS"};for(int i=0;i<5;++i){editor.addAndMakeVisible(mutes[i]);mutes[i].getProperties().set("layer",true);mutes[i].setButtonText(layers[i]);mutes[i].onClick=[this,i]{p.setValue("mutes",(float)((unsigned)p.value("mutes")^(1u<<i)));};mutes[i].setTooltip("Mute "+juce::String(layers[i]).toLowerCase());}
        auto* main=new GroupPage();main->addGroup(p,"MIX",{P_CHORD,P_PINGS,P_BASS,P_DRUMS,P_CRACKLE,P_DUCK},5);main->addGroup(p,"CHORD",{P_CUTOFF,P_DECAY,P_STABS,P_DRIFT,P_EVOLVE,P_MOTION},0);main->addGroup(p,"TEXTURE",{P_DENSITY,P_PTONE,P_POCT,P_GROOVE,P_BASSOCT,P_FIFTH},6);main->addGroup(p,"SPACE",{P_ECHO,P_FEEDBACK,P_ETIME,P_REVERB,P_SIZE,P_CLOUD},4);
        tabs.addTab("PLAY",background,main,true);
        auto* sound=new GroupPage();sound->addGroup(p,"CHORD VOICE",{P_CVOICE,P_CATT,P_CCOL,P_CRES,P_CENV,P_CALG,P_CFRAT,P_CFB,P_CFDEC,P_TUNE},0);sound->addGroup(p,"PING VOICE",{P_PVOICE,P_PTON,P_PRAT,P_PLEN,P_PBEND,P_PALG,P_PFRAT,P_PFB,P_PFDEC,P_TEMPO},2);sound->addGroup(p,"BASS VOICE",{P_BVOICE,P_BBITE,P_BSHAPE,P_BLEN,P_BSLIDE,P_BALG,P_BFRAT,P_BFB,P_BFDEC,P_GROOVE},1);tabs.addTab("VOICES",background,sound,true);
        tabs.addTab("CHORDS",background,new Chords(p),true);tabs.addTab("DRUMS",background,new Drums(p),true);tabs.addTab("PERFORM",background,new Perform(p),true);
        tabs.addTab("DUCKING",background,new Ducking(p),true);
        tabs.setComponentID("pages");tabs.setTabBarDepth(36);tabs.setOutline(0);tabs.setColour(juce::TabbedComponent::backgroundColourId,background);
    }
    void refresh(){refreshing=true;piece.setSelectedId(p.getCurrentProgram()+1,juce::dontSendNotification);scaleMode.setSelectedId(p.value("scale")>0?9:p.engineValue(P_MODE)+1,juce::dontSendNotification);int pool=(int)p.scaleMask(),mute=(int)p.value("mutes"),rootNote=p.engineValue(P_ROOT);for(int i=0;i<12;++i){scale[i].setButtonText(notes[(i+rootNote)%12]);scale[i].setToggleState(pool>>i&1,juce::dontSendNotification);}for(int i=0;i<5;++i)mutes[i].setToggleState(!(mute>>i&1),juce::dontSendNotification);refreshing=false;for(int i=0;i<tabs.getNumTabs();++i)if(auto* page=dynamic_cast<GroupPage*>(tabs.getTabContentComponent(i)))page->advance();tabs.getCurrentContentComponent()->repaint();}
};
DubEditor::DubEditor(DubProcessor& p):AudioProcessorEditor(p),ui(std::make_unique<Impl>(*this,p)),processor(p){setResizable(true,true);setResizeLimits(1040,760,1500,1000);setSize(1100,760);ui->refresh();startTimerHz(24);}
DubEditor::~DubEditor(){stopTimer();processor.clearMomentary();setLookAndFeel(nullptr);ui.reset();}
void DubEditor::paint(juce::Graphics& g) {
    using namespace dubui;
    auto bounds=getLocalBounds().toFloat();
    g.setGradientFill(juce::ColourGradient(juce::Colour(0xff15171d),0,0,juce::Colour(0xff090b10),0,(float)getHeight(),false));g.fillAll();
    g.setColour(edge);g.drawRoundedRectangle(bounds.reduced(8),8,.8f);
    g.setColour(edge.brighter(.12f));g.drawHorizontalLine(19,26.f,(float)getWidth()-26);g.drawHorizontalLine(getHeight()-19,26.f,(float)getWidth()-26);
    for(auto c:{juce::Point<float>{23,34},juce::Point<float>{(float)getWidth()-23,34},juce::Point<float>{23,(float)getHeight()-34},juce::Point<float>{(float)getWidth()-23,(float)getHeight()-34}})screw(g,c);
    auto logo=juce::Font{juce::FontOptions("Helvetica Neue",28,juce::Font::plain)};logo.setExtraKerningFactor(.19f);g.setFont(logo);g.setColour(ink);
    g.drawText("PXL",juce::Rectangle<int>{48,31,88,40},juce::Justification::centredLeft);g.drawText("DUB",juce::Rectangle<int>{145,31,100,40},juce::Justification::centredLeft);
    g.setColour(muted);g.drawLine(135,39,126,66,.7f);
    text(g,"GENERATIVE SYNTHESIS SYSTEM",{49,74,270,17},8,muted);
    text(g,"2126",{getWidth()-166,35,88,18},11,violet,juce::Justification::centredRight);
    text(g,"SERIES / 01",{getWidth()-176,55,98,18},8,muted,juce::Justification::centredRight);
    g.setColour(edge);g.drawHorizontalLine(100,48.f,(float)getWidth()-48);
    interference(g,{48,104,(float)getWidth()-96,22});
    text(g,"TONALITY",{48,130,78,29},9,muted);text(g,"LAYER",{getWidth()-436,130,50,29},9,muted);
    g.setColour(edge);g.drawHorizontalLine(211,48.f,(float)getWidth()-48);
    auto& a=processor.activity;const int root=juce::jlimit(0,11,a.root.load());
    juce::String tones;
    for(auto& n:a.chord){const int pitch=(n.load()%12+12)%12;if(tones.isNotEmpty())tones+=" / ";tones+=notes[pitch];}
    const auto chord=processor.currentChordName();
    text(g,chord,{48,getHeight()-49,75,28},14,ink);text(g,tones,{124,getHeight()-48,260,26},9,muted);
    text(g,juce::String(a.tempo.load(),1)+" BPM",{getWidth()/2-75,getHeight()-48,150,26},11,ink,juce::Justification::centred);
    text(g,juce::String(sectionName(a.section.load())).toUpperCase()+" / "+juce::String(a.phraseBar.load()+1).paddedLeft('0',2)+":08",{getWidth()/2+145,getHeight()-48,185,26},9,muted);
    g.setColour(a.running.load()?accent:edge);g.fillEllipse((float)getWidth()-93,(float)getHeight()-38,3,3);
    text(g,a.running.load()?"RUNNING":"REST",{getWidth()-83,getHeight()-48,35,26},8,muted,juce::Justification::centredRight);
}
void DubEditor::resized() {
    auto& u=*ui;const int w=getWidth(),h=getHeight();
    u.piece.setBounds(278,37,190,40);u.run.setBounds(486,43,68,30);u.sync.setBounds(564,43,92,30);u.hold.setBounds(666,43,103,30);u.menu.setBounds(w-62,43,28,30);
    u.root.setBounds(126,130,48,29);u.scaleMode.setBounds(181,130,105,29);
    const int sw=juce::jmin(27,(w-780)/12);
    for(int i=0;i<12;++i)u.scale[i].setBounds(300+i*sw,130,sw-3,29);
    for(int i=0;i<5;++i)u.mutes[i].setBounds(w-386+i*67,130,62,29);
    u.tabs.setBounds(43,176,w-86,h-280);
    u.trace.setBounds(48,h-91,w-96,36);u.output.setBounds(w-258,h-88,198,30);
}
void DubEditor::timerCallback() {
    ui->refresh();if(!juce::ModifierKeys::getCurrentModifiersRealtime().isAnyMouseButtonDown())processor.clearMomentary();ui->trace.repaint();repaint();
}
