#pragma once
#include <cstdint>
namespace pxldub {
#include "../third_party/dub1/amb.h"
class Engine;
const en_param_t& parameterInfo(int index);
const char* pieceName(int index);
const char* voiceName(int layer, int index);
const char* modeName(int index);
unsigned modePool(int index);
const char* effectName(int index);
const char* sectionName(int index);
void parameterText(int index, int value, char* out);
}
