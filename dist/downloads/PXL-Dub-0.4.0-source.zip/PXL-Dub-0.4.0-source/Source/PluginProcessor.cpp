#include "PluginProcessor.h"
#include "Engine.generated.h"
#include "PluginEditor.h"
#include <new>
#include <limits>
using namespace pxldub;

namespace {
// This descriptor instance is never rendered or changed; only pure metadata methods are used.
Engine& descriptors() { static auto instance = std::make_unique<Engine>(); return *instance; }
}
namespace pxldub {
const en_param_t& parameterInfo(int p) { return *descriptors().en_param_info(p); }
const char* pieceName(int p) { return descriptors().en_piece_name(juce::jlimit(0,7,p)); }
const char* voiceName(int layer, int p) {
    auto& d = descriptors();
    return layer == 0 ? d.EN_CV_NAME[juce::jlimit(0,6,p)] : layer == 1 ? d.EN_PV_NAME[juce::jlimit(0,4,p)] : layer == 2 ? d.EN_BV_NAME[juce::jlimit(0,4,p)] : d.EN_KIT_NAME[juce::jlimit(0,4,p)];
}
const char* modeName(int p) { return descriptors().EN_MODE_NAME[juce::jlimit(0,7,p)]; }
unsigned modePool(int p) { return descriptors().EN_MODE_POOL[juce::jlimit(0,7,p)]; }
const char* effectName(int p) { return descriptors().EN_FX_NAME[juce::jlimit(0,15,p)]; }
const char* sectionName(int p) { return descriptors().EN_SEC_NAME[juce::jlimit(0,3,p)]; }
void parameterText(int p, int v, char* out) { descriptors().en_param_text(p,v,out); }
}

juce::AudioProcessorValueTreeState::ParameterLayout DubProcessor::createLayout() {
    juce::AudioProcessorValueTreeState::ParameterLayout layout;
    int16_t basic[P_NPARAMS]; uint16_t pool; descriptors().en_piece(0,basic,&pool);
    for (int p = 0; p < P_NPARAMS; ++p) {
        // The upstream MIDI-output switch is retained in the source, but this instrument has no MIDI output bus.
        if (p == P_MIDI) continue;
        const auto& info = parameterInfo(p);
        auto attr = juce::AudioParameterIntAttributes().withStringFromValueFunction([p](int v, int) {
            char out[32]{}; parameterText(p,v,out); return juce::String(out);
        });
        layout.add(std::make_unique<juce::AudioParameterInt>(juce::ParameterID(engineID(p),1), info.name, info.lo, info.hi, basic[p], attr));
    }
    auto boolean = [&](const char* id,const char* name,bool def) { layout.add(std::make_unique<juce::AudioParameterBool>(juce::ParameterID(id,1),name,def)); };
    boolean("sync","Host sync",true); boolean("run","Run",true); boolean("hold","Dub hold",false);
    layout.add(std::make_unique<juce::AudioParameterInt>(juce::ParameterID("scale",1),"Custom scale (0 follows mode)",0,4095,0));
    layout.add(std::make_unique<juce::AudioParameterInt>(juce::ParameterID("mutes",1),"Layer mutes",0,31,0));
    layout.add(std::make_unique<juce::AudioParameterFloat>(juce::ParameterID("output",1),"Output",juce::NormalisableRange<float>(-48,6,.1f),-3.f,juce::AudioParameterFloatAttributes().withLabel("dB")));
    layout.add(std::make_unique<juce::AudioParameterFloat>(juce::ParameterID("duck_release",1),"Kick duck recovery",juce::NormalisableRange<float>(20,800,1,.5f),130.f,juce::AudioParameterFloatAttributes().withLabel("ms")));
    for(const auto* id:duckIDs)layout.add(std::make_unique<juce::AudioParameterFloat>(juce::ParameterID(id,1),juce::String(id).replaceCharacter('_',' '),juce::NormalisableRange<float>(0,100,1),100.f,juce::AudioParameterFloatAttributes().withLabel("%")));
    return layout;
}
DubProcessor::DubProcessor() : AudioProcessor(BusesProperties().withOutput("Stereo",juce::AudioChannelSet::stereo(),true)),
    engine(std::make_unique<Engine>()), state(*this,nullptr,"PXL_DUB",createLayout()) {
    engine->en_init(); applied.fill(std::numeric_limits<int>::min());
    for (int p=0;p<P_NPARAMS;++p) raw[p]=state.getRawParameterValue(engineID(p));
    syncControl=state.getRawParameterValue("sync");runControl=state.getRawParameterValue("run");
    holdControl=state.getRawParameterValue("hold");scaleControl=state.getRawParameterValue("scale");
    muteControl=state.getRawParameterValue("mutes");outputControl=state.getRawParameterValue("output");
    duckReleaseControl=state.getRawParameterValue("duck_release");
    for(int i=0;i<6;++i)layerDuckControls[i]=state.getRawParameterValue(duckIDs[i]);
    updateActivity();
}
DubProcessor::~DubProcessor() = default;
float DubProcessor::value(const juce::String& id) const { auto* p=state.getRawParameterValue(id); return p ? p->load() : 0.f; }
void DubProcessor::setValue(const juce::String& id,float v) { if(auto* p=state.getParameter(id)) { p->beginChangeGesture();p->setValueNotifyingHost(p->convertTo0to1(v));p->endChangeGesture(); } }
int DubProcessor::engineValue(int p) const { return p>=0 && p<P_NPARAMS && raw[p] ? juce::roundToInt(raw[p]->load()) : 0; }
unsigned DubProcessor::scaleMask() const {const auto custom=(unsigned)juce::roundToInt(scaleControl->load());return (custom?custom:modePool(engineValue(P_MODE)))|1u;}
juce::String DubProcessor::currentChordName() const {
    std::array<int,5> pitches{};pitches[0]=juce::jlimit(0,11,activity.root.load());
    for(int i=0;i<4;++i)pitches[i+1]=(activity.chord[i].load()%12+12)%12;
    char name[32]{};return descriptors().en_chord_name(pitches.data(),(int)pitches.size(),name);
}
void DubProcessor::loadPiece(int p) {
    p=juce::jlimit(0,7,p); int16_t recipe[P_NPARAMS];uint16_t pool; descriptors().en_piece(p,recipe,&pool);
    transaction.fetch_add(1);
    for(int i=0;i<P_NPARAMS;++i) if(i!=P_MIDI && i!=P_TUNE) setEngineValue(i,recipe[i]);
    setValue("scale",0);currentPiece.store(p);setValue("hold",0);setValue("mutes",0);
    incomingEnabled.store(false);
    resetRequested.store(true); transaction.fetch_add(1);
}
void DubProcessor::prepareToPlay(double rate,int) {
    sampleRate=std::isfinite(rate)&&rate>=8000?rate:44100.; ratio=44100./sampleRate;
    hardReset(); available=0;leftResampler.reset();rightResampler.reset();
    wasPlaying=false;hadPosition=false;panicLatched=false;
    setLatencySamples(juce::roundToInt(2./ratio));
}
void DubProcessor::hardReset() {
    preservedPingsPending=hasRendered&&!resetRequested.load();
    if(preservedPingsPending)engine->en_pings_get(preservedPings.data());
    engine->~Engine();new(engine.get()) Engine{};engine->en_init();
    engine->nativeDucking=true;appliedDuckRelease=-1;
    meterEnvelopes.fill(0);reductionEnvelope=0;
    applied.fill(std::numeric_limits<int>::min()); appliedScale=appliedHold=appliedMutes=-1;
    appliedPerformance=appliedEffects=0;
}
void DubProcessor::applyControls() {
    auto version=transaction.load(); if(version&1u) return;
    std::array<int,P_NPARAMS> values{};
    for(int p=0;p<P_NPARAMS;++p) values[p]=raw[p]?juce::roundToInt(raw[p]->load()):0;
    int pool=juce::roundToInt(scaleControl->load()),hold=juce::roundToInt(holdControl->load()),mutes=juce::roundToInt(muteControl->load());
    pool=(pool?pool:(int)modePool(values[P_MODE]))|1;
    if(transaction.load()!=version) return;
    // Direct apply is safe: the engine belongs exclusively to the audio callback.
    for(int p=0;p<P_NPARAMS;++p) if(values[p]!=applied[p]) { engine->apply(p,values[p]);applied[p]=values[p]; }
    const float release=duckReleaseControl->load();
    if(release!=appliedDuckRelease){engine->setDuckRelease(release);appliedDuckRelease=release;}
    for(int i=0;i<6;++i)engine->setLayerDuck(i,layerDuckControls[i]->load()*.01f);
    if(pool!=appliedScale) {engine->pool_set((uint32_t)pool);appliedScale=pool;}
    if(hold!=appliedHold) {engine->en_frozen=(uint8_t)hold;appliedHold=hold;}
    if(mutes!=appliedMutes) {engine->mutes=(uint32_t)mutes;engine->lanes();appliedMutes=mutes;}
    auto pf=performance.load(),fx=effects.load();
    if(pf!=appliedPerformance) {engine->perf=pf;engine->lanes();appliedPerformance=pf;}
    if(fx!=appliedEffects) {engine->fxm=fx;appliedEffects=fx;}
    const auto incoming=incomingVersion.load();
    const bool reset=resetRequested.exchange(false);
    if(reset) { engine->pings_have=0;engine->regrow(); }
    if(preservedPingsPending) {for(int i=0;i<EN_PINGS_N;++i)engine->pings_pend[i]=preservedPings[i];engine->pings_have=1;engine->pings_take();preservedPingsPending=false;}
    if(incomingEnabled.load() && incoming && !(incoming&1u) && incoming!=consumedIncoming) {
        std::array<uint8_t,EN_PINGS_N> data{};for(int i=0;i<EN_PINGS_N;++i)data[i]=incomingPings[i].load();
        if(incoming==incomingVersion.load()) {for(int i=0;i<EN_PINGS_N;++i)engine->pings_pend[i]=data[i];engine->pings_have=1;engine->pings_take();consumedIncoming=incoming;}
    }
    if(regrowRequested.exchange(false)) {engine->pings_have=0;engine->regrow();}
    if(nextRequested.exchange(false)) {if(engine->en_playing)engine->change_pending=1;else engine->chord_change();}
}
void DubProcessor::renderSource(int required) {
    while(available<required) {
        // A fixed engine quantum keeps the original block-rate smoothing consistent across host buffers.
        engine->step_len=(float)(44100.*60./(clockTempo*4.));
        engine->echo_len_t=juce::jmin((float)(TAPE_N-8),engine->ETIME_BEATS[engine->par[P_ETIME]]*(float)(60./clockTempo)*TAPE_SR);
        engine->en_render(engineBuffer.data(),64,3072);
        for(int bus=0;bus<5;++bus)blockPeaks[bus]=juce::jmax(blockPeaks[bus],engine->visualPeak[bus]);
        blockReduction=juce::jmax(blockReduction,engine->visualReduction);
        for(int i=0;i<64;++i){sourceL[available+i]=(float)engineBuffer[2*i]/8388608.f;sourceR[available+i]=(float)engineBuffer[2*i+1]/8388608.f;}
        available+=64;
    }
}
void DubProcessor::processBlock(juce::AudioBuffer<float>& audio,juce::MidiBuffer& midi) {
    juce::ScopedNoDenormals noDenormals;audio.clear();midi.clear();
    blockPeaks.fill(0);blockReduction=0;
    const bool sync=syncControl->load()>.5f,run=runControl->load()>.5f;
    bool hostPlaying=false,positionValid=false;double ppq=0,tempo=raw[P_TEMPO]->load();
    if(auto* head=getPlayHead()) if(auto pos=head->getPosition()) {
        hostPlaying=pos->getIsPlaying();
        if(auto b=pos->getBpm()) if(std::isfinite(*b)&&*b>0&&sync)tempo=*b;
        if(auto q=pos->getPpqPosition()) if(std::isfinite(*q)){positionValid=true;ppq=*q;}
    }
    clockTempo=juce::jlimit(10.,1000.,tempo);
    const bool requested=run && (!sync || hostPlaying);
    if(!requested)panicLatched=false;
    bool playing=requested && !panicLatched;
    bool seek=sync && playing && wasPlaying && positionValid && hadPosition && std::abs(ppq-expectedPpq) > .02;
    if(panicRequested.exchange(false)) {
        hardReset();panicLatched=true;playing=false;available=0;leftResampler.reset();rightResampler.reset();
    }
    applyControls();
    if(playing!=wasPlaying || seek || sync!=wasSync) {
        if(playing)engine->play_start(1);else engine->play_stop();
        available=0;leftResampler.reset();rightResampler.reset();
    }
    wasPlaying=playing;wasSync=sync;hadPosition=positionValid;
    expectedPpq=ppq+(playing?audio.getNumSamples()/sampleRate*clockTempo/60.:0.);
    float peak=0;const auto gain=juce::Decibels::decibelsToGain(outputControl->load());
    for(int offset=0;offset<audio.getNumSamples();) {
        const int n=juce::jmin(128,audio.getNumSamples()-offset);
        const int need=(int)std::ceil(n*ratio)+8;
        renderSource(need);
        if(audio.getNumChannels()>=2) {
            const int consumed=leftResampler.process(ratio,sourceL.data(),audio.getWritePointer(0,offset),n);
            rightResampler.process(ratio,sourceR.data(),audio.getWritePointer(1,offset),n);
            available-=consumed;
            if(consumed>0) {
                std::move(sourceL.begin()+consumed,sourceL.begin()+consumed+available,sourceL.begin());
                std::move(sourceR.begin()+consumed,sourceR.begin()+consumed+available,sourceR.begin());
            }
            for(int c=0;c<2;++c)for(int i=0;i<n;++i){float& x=audio.getWritePointer(c,offset)[i];x*=gain;peak=juce::jmax(peak,std::abs(x));}
        }
        offset+=n;
    }
    blockPeaks[5]=peak;
    const float meterDecay=std::exp(-(float)(audio.getNumSamples()/(sampleRate*.16)));
    for(int bus=0;bus<6;++bus){meterEnvelopes[bus]=juce::jmax(blockPeaks[bus]*(bus==5?1.f:gain),meterEnvelopes[bus]*meterDecay);activity.buses[bus].store(meterEnvelopes[bus],std::memory_order_relaxed);}
    reductionEnvelope=juce::jmax(blockReduction,reductionEnvelope*meterDecay);
    activity.duckReduction.store(reductionEnvelope,std::memory_order_relaxed);
    activity.peak.store(peak);activity.tempo.store((float)clockTempo);updateActivity();hasRendered=true;
    activity.visualSequence.fetch_add(1,std::memory_order_relaxed);
    publishedIncoming.store(consumedIncoming);
}
void DubProcessor::updateActivity() {
    activity.running.store(engine->en_playing!=0);activity.steps.store((int)engine->en_bars);activity.root.store(engine->en_chord_root);activity.section.store(engine->en_section);activity.phraseBar.store(engine->en_phrase_bar);
    for(int i=0;i<4;++i)activity.chord[i].store(engine->en_chord[i]);
    activity.levels[0].store(engine->en_pad_level);activity.levels[1].store(engine->en_bass_level);
    for(int i=0;i<4;++i)activity.levels[2+i].store(engine->en_loop_glow[i]);
    for(int i=0;i<3;++i)activity.levels[6+i].store(engine->en_drum_glow[i]);
    const auto scopePosition=engine->en_scope_w;
    for(size_t i=0;i<activity.scope.size();++i)activity.scope[i].store((float)engine->en_scope[(scopePosition+i*2)&(EN_SCOPE_N-1)]/32768.f,std::memory_order_relaxed);
    std::array<uint8_t,EN_PINGS_N> pings{};engine->en_pings_get(pings.data());
    pingVersion.fetch_add(1);for(int i=0;i<EN_PINGS_N;++i)savedPings[i].store(pings[i]);pingVersion.fetch_add(1);
}
std::array<uint8_t,EN_PINGS_N> DubProcessor::pingSnapshot() const {
    std::array<uint8_t,EN_PINGS_N> data{};
    for(;;) {auto v=pingVersion.load();if(v&1u)continue;for(int i=0;i<EN_PINGS_N;++i)data[i]=savedPings[i].load();if(pingVersion.load()==v)return data;}
}
void DubProcessor::getStateInformation(juce::MemoryBlock& dest) {
    auto tree=state.copyState();tree.setProperty("version",1,nullptr);tree.setProperty("piece",currentPiece.load(),nullptr);
    auto pings=pingSnapshot();bool includePings=!resetRequested.load();
    if(incomingEnabled.load()) {
        for(;;) {auto v=incomingVersion.load();if(v&1u)continue;if(v==0||v==publishedIncoming.load())break;for(int i=0;i<EN_PINGS_N;++i)pings[i]=incomingPings[i].load();if(v==incomingVersion.load()){includePings=true;break;}}
    }
    if(includePings)tree.setProperty("pings",juce::MemoryBlock(pings.data(),pings.size()).toBase64Encoding(),nullptr);
    else tree.removeProperty("pings",nullptr);
    if(auto xml=tree.createXml())copyXmlToBinary(*xml,dest);
}
void DubProcessor::setStateInformation(const void* data,int size) {
    auto xml=getXmlFromBinary(data,size);if(!xml || !xml->hasTagName("PXL_DUB"))return;
    auto tree=juce::ValueTree::fromXml(*xml);if((int)tree.getProperty("version",1)!=1)return;
    juce::MemoryBlock pings;pings.fromBase64Encoding(tree.getProperty("pings").toString());
    transaction.fetch_add(1);state.replaceState(tree);currentPiece.store(juce::jlimit(0,7,(int)tree.getProperty("piece",0)));clearMomentary();
    incomingEnabled.store(pings.getSize()==EN_PINGS_N);
    if(pings.getSize()==EN_PINGS_N) {incomingVersion.fetch_add(1);for(int i=0;i<EN_PINGS_N;++i)incomingPings[i].store(((const uint8_t*)pings.getData())[i]);incomingVersion.fetch_add(1);}
    resetRequested.store(true);transaction.fetch_add(1);
}
juce::AudioProcessorEditor* DubProcessor::createEditor() { return new DubEditor(*this); }
juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter() { return new DubProcessor(); }
