#pragma once
#include <algorithm>
#include <cmath>
namespace dubui {
struct SignalFeed {
    unsigned lastSequence{0};float age{0};
    bool advance(unsigned sequence,float seconds) {
        if(sequence!=lastSequence){lastSequence=sequence;age=0;}
        else age=std::min(1.f,age+std::max(0.f,seconds));
        return age<.25f;
    }
};
// Message-thread only: motion has no clock of its own while the signal is silent.
struct SignalMotion {
    float amount{0}, phase{0};
    void advance(float level,float seconds) {
        if(!std::isfinite(level))level=0;
        seconds=std::clamp(seconds,0.f,.25f);
        const float target=std::sqrt(std::clamp(level*8.f,0.f,1.f));
        amount+=(target-amount)*(1.f-std::exp(-seconds/(target>amount?.065f:.26f)));
        if(amount<.0001f&&target==0){amount=0;phase=0;return;}
        phase=std::fmod(phase+seconds*amount*2.2f,6.283185307f);
    }
};
}
