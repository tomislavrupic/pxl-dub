#pragma once
#include "PluginProcessor.h"
class DubEditor final : public juce::AudioProcessorEditor, private juce::Timer {
public:
    explicit DubEditor(DubProcessor&);
    ~DubEditor() override;
    void paint(juce::Graphics&) override;
    void resized() override;
private:
    struct Impl;
    std::unique_ptr<Impl> ui;
    DubProcessor& processor;
    void timerCallback() override;
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(DubEditor)
};
