PXL Dub0.4.0 corresponding source

Native: macOS, Xcode command line tools and CMake3.25+. Run cmake -S . -B build -DCMAKE_BUILD_TYPE=Release then cmake --build build -j8. The exact JUCE8.0.14 modules, CMake files and helper-tool sources used by this build are included; unrelated JUCE examples/docs/assets are omitted. Licenses remain alongside the code.

Web: install the official WASI SDK34 for your OS, set WASI_SDK_PATH, then run web/tools/build-engine.sh. Serve web/dist with an HTTP server (localhost or HTTPS); file:// does not support AudioWorklet. Node is used for metadata and tests. No synth runtime dependencies or WASI imports are required.

The developer integration script tools/build_web.py assumes a sibling PXLDub-Web checkout; the standalone web build above is the source-package route.
