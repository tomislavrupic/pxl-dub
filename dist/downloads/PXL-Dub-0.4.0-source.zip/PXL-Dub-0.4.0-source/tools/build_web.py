#!/usr/bin/env python3
"""Build a freestanding WebAssembly engine and sync its corresponding source."""
from pathlib import Path
import subprocess, shutil, re, json
root=Path(__file__).resolve().parents[1]
site=root.parent/'PXLDub-Web'
sdk=root/'build/toolchains/wasi-sdk-34.0-arm64-macos'
for name in ['Engine.generated.h','WebBridge.cpp']:
 shutil.copy2(root/'Source'/name,site/'engine/Source'/name)
for name in ['amb.h','fastmath.h','amb.c','LICENSING.md']:
 shutil.copy2(root/'third_party/dub1'/name,site/'engine/third_party/dub1'/name)
for name in ['LICENSE','THIRD-PARTY-NOTICES.md']:
 shutil.copy2(root/name,site/name)
exports=re.findall(r'\b(dub_\w+)\(', (root/'Source/WebBridge.cpp').read_text())
command=[str(sdk/'bin/clang++'),'-std=c++17','-O2','-ffp-contract=off','-fno-exceptions','-fno-rtti','-DEN_HOST','-nostartfiles','-Wl,--no-entry','-Wl,--export-memory','-Wl,--export=__wasm_call_ctors','-Wl,--initial-memory=16777216','-Wl,--max-memory=16777216','-Wl,-z,stack-size=1048576']+[f'-Wl,--export={name}' for name in dict.fromkeys(exports)]+[str(site/'engine/Source/WebBridge.cpp'),'-o',str(site/'dist/engine.wasm')]
subprocess.run(command,check=True)
subprocess.run(['clang++','-std=c++17','-O2','-ffp-contract=off','-DEN_HOST',str(root/'Source/WebBridge.cpp'),str(root/'Tests/WebEngineOracle.cpp'),'-o',str(root/'build/WebEngineOracle')],check=True)
subprocess.run([str(root/'build/WebEngineOracle'),str(site/'tests/native-oracle.pcm')],check=True)
header=(root/'third_party/dub1/amb.h').read_text();header=header[header.index('P_CHORD'):header.index('P_NPARAMS')]
header=re.sub(r'/\*.*?\*/','',header,flags=re.S)
keys=re.findall(r'\bP_(\w+)\b',header)
(site/'tests/parameter-keys.json').write_text(json.dumps(keys))
print('Wasm engine, native oracle and standalone source synchronized')
