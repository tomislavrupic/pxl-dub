#!/bin/bash
set -euo pipefail
PXL_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PXL_PACKAGE="$PXL_ROOT/dist/PXL-Dub-0.4.0-macOS-arm64"
PXL_JUCE="${JUCE_PATH:-/Users/thecore/Documents/00 Pixel Records Studio/Titty Tweeter/TittyTweeter/third_party/JUCE}"
if [[ -d "$PXL_ROOT/third_party/JUCE" ]]; then PXL_JUCE="$PXL_ROOT/third_party/JUCE"; fi
mkdir -p "$PXL_PACKAGE/AU" "$PXL_PACKAGE/VST3" "$PXL_PACKAGE/evidence" "$PXL_PACKAGE/source/third_party"
for PXL_FORMAT in AU VST3; do
    if [[ "$PXL_FORMAT" == AU ]]; then PXL_NAME="PXL Dub.component"; else PXL_NAME="PXL Dub.vst3"; fi
    ditto "$PXL_ROOT/build/PXLDub_artefacts/Release/$PXL_FORMAT/$PXL_NAME" "$PXL_PACKAGE/$PXL_FORMAT/$PXL_NAME"
    codesign --force --deep --sign - "$PXL_PACKAGE/$PXL_FORMAT/$PXL_NAME"
    codesign --verify --deep --strict "$PXL_PACKAGE/$PXL_FORMAT/$PXL_NAME"
done
cp "$PXL_ROOT/tools/Install.command" "$PXL_PACKAGE/Install.command"
chmod +x "$PXL_PACKAGE/Install.command"
cp "$PXL_ROOT/README.md" "$PXL_ROOT/LICENSE" "$PXL_ROOT/THIRD-PARTY-NOTICES.md" "$PXL_PACKAGE/"
rsync -a --exclude '.git' --exclude build --exclude dist --exclude 'PXL-Dub-*.png' "$PXL_ROOT/" "$PXL_PACKAGE/source/"
rsync -a --exclude '.git' "$PXL_JUCE/" "$PXL_PACKAGE/source/third_party/JUCE/"
cp "$PXL_ROOT/docs/VALIDATION.md" "$PXL_PACKAGE/evidence/"
cp "$PXL_ROOT/build/pluginval-vst3.log" "$PXL_ROOT/build/Testing/Temporary/LastTest.log" "$PXL_PACKAGE/evidence/"
if [[ -f "$PXL_ROOT/build/installed-auval.log" ]]; then cp "$PXL_ROOT/build/installed-auval.log" "$PXL_PACKAGE/evidence/"; fi
cp "$PXL_ROOT/PXL-Dub-editor.png" "$PXL_PACKAGE/"
cp "$PXL_ROOT/build/PXL-Dub-demo.wav" "$PXL_PACKAGE/"
ditto -c -k --keepParent "$PXL_PACKAGE" "$PXL_ROOT/dist/PXL-Dub-0.4.0-macOS-arm64.zip"
echo "$PXL_ROOT/dist/PXL-Dub-0.4.0-macOS-arm64.zip"
