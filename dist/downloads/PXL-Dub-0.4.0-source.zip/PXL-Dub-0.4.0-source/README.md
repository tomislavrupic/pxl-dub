# PXL Dub 0.4.0

The 2126 interface uses dark ceramic panels, calibrated spectral knob rings,
engraved signal glyphs and restrained interference linework. Its compact output
trace follows actual engine audio; display scaling affects the trace only.
The header menu contains Next chord, New pattern and Panic.

The small etched graphics now brighten and flex with their own sound: Mix follows
the output, Chord the stabs, Texture bass/pings and Space the wet returns, including
tails after transport stop. Voices follow their individual buses. Motion settles
back to a static etching at silence; the audio thread never draws graphics.

**Kick sidechain:** on Play, Duck sets how deeply the kick pushes down the other
internal layers, up to approximately 12 dB. Recovery below the Mix knobs adjusts
the return from 20–800 ms (130 ms by default); the small bar/dB readout shows peak
gain reduction. Chord, pings, bass, non-kick drums, wet effects and vinyl all duck;
the kick keeps its full level. Duck at zero bypasses attenuation. Muting Kick or
setting Drums to zero prevents new triggers and lets existing reduction recover.
This is internal kick ducking; it does not take an external DAW sidechain input.

**Individual pumping:** the Ducking tab gives Chord, Pings, Bass, Percussion,
Vinyl and Space their own 0–100% amount. Zero leaves that layer steady; 100%
applies the full master Duck depth. Amount changes ease over about 5 ms. The
shared Recovery controls the return. All amounts default to 100%, preserving
0.3.0's sound and loading compatible defaults into older sessions.

**Browser instrument and downloads:** https://tomislavrupic.github.io/pxl-dub/
The browser uses the same engine compiled to WebAssembly, its own transport and
tempo, the 2126 interface and local patch save/JSON import/export. Saved patches
include generated ping loops. Click Start audio; page loading never auto-starts
audio. Browser patches are separate from AU/VST3 host sessions.

Native macOS AU and VST3 generative dub instrument, ported from
[DUB-1](https://github.com/sbegueria/fm1-dub) by sbegueria, itself based on
Charles Vestal's AMB-1 and the Felucca platform.

PXL Dub makes its own notes: chord stabs, four interlocking FM ping loops,
sub bass and drums through tape echo, granular cloud and plate reverb. The eight
original pieces and sound engines are retained. Incoming MIDI notes do not play
individual voices; steer the piece with its scale, sounds and performance controls.
The plugin accepts and consumes host MIDI messages for instrument-host compatibility.

## Install and play

The macOS package contains `AU/PXL Dub.component` and `VST3/PXL Dub.vst3`.
Run `Install.command` to install them for the current user, or copy them into
`~/Library/Audio/Plug-Ins/Components` and `~/Library/Audio/Plug-Ins/VST3` respectively.
The installer moves any existing PXL Dub bundles into a dated backup first.
Rescan plugins in the DAW if necessary.

Load PXL Dub as an instrument. RUN and HOST SYNC are enabled by default:
start the DAW transport to hear the piece. Turn HOST SYNC off to use the internal
tempo (Voices tab) and RUN while the DAW is stopped. Output starts at -3 dB.
The builds are Apple Silicon arm64, macOS 12 or later, locally ad-hoc signed.

- **Play:** layer levels, stabs, movement, bass groove and space. The five layer
  buttons stay lit when audible; click one to mute it. Drums is the complete drum
  mix; Kick and Hats are performance mutes for their respective groups.
- **Ducking:** master depth, recovery and independent amounts for six internal buses.
- **Voices:** original chord, ping and bass sounds, relative tone/envelope controls,
  nine FM algorithms, ratio, feedback and modulator decay. FM controls affect FM
  voices. Internal Tempo and Tune are here too.
- **Chords:** eight root/kind/extension slots and random or ordered playback.
  Empty slots hold the previous chord. Next chord in the header menu advances at the next bar.
- **Drums:** five custom 16-step lanes. Click a step for a hit; Shift-click for
  an accent. Select Custom to play the edited pattern. Chance controls are per lane.
- **Perform:** hold a pad for a dub move or an effect; release to return.
  DUB HOLD is a separate persistent echo/cloud hold.
- **Scale:** choose root and mode, or toggle the twelve relative pitch classes.
  The root always remains in the pool. Editing notes selects Custom. Mode automation
  applies while the custom-scale parameter is zero; a nonzero custom mask overrides
  mode. Choosing a named mode returns to mode following.
- **New pattern (header menu):** rebuild the generated loops and rhythms. Choosing a piece
  loads its original recipe; the DAW saves the currently edited piece and loops.
- **Panic (header menu):** silence the instrument and clear effect buffers, preserving musical
  ping loops. Toggle RUN off/on or stop/start the host to resume after Panic.

Host start and transport seeks start a fresh phrase. Host stop lets effect tails
ring away. Host tempo, including fractional values and tempos outside the original
hardware UI range, drives the clock and echo without changing saved internal tempo.
Processing stays at 44.1 kHz internally; a streaming cubic interpolator converts
to the host rate and reports its two-engine-sample latency.

The DAW saves parameters, custom scale, chord/drum edits, selected factory piece
and generated ping loops. Running echo/reverb audio is transient. Momentary pads
are released on editor close and on state restore. Factory-piece selection uses
the host program interface; it is not an automatable parameter.

## Build and tests

Requires macOS, Xcode command line tools, CMake 3.25+ and JUCE 8. The source package
includes the JUCE 8.0.14 modules and build tools used by this build in `third_party/JUCE`.
For a checkout without the bundled dependency, pass `-DJUCE_PATH=/path/to/JUCE`.

```sh
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j 8
ctest --test-dir build --output-on-failure -j 2
```

`EngineTests` compares audible renders against unmodified upstream C for all eight
pieces, with a second interleaved instance. `UpstreamTests` runs the original DSP
suite. `ProcessorTests` covers host transport, sample rates/buffers, tempo, state,
panic, musical-loop retention and allocation-free callbacks. `AUWrapperTests`
loads the AU factory directly and checks real AU rendering/state/tails without
requiring an installed plugin.

`MeterTests` verifies silent/isolated buses and wet tails. `DuckingTests` covers
layer/wet attenuation, untouched kick, recovery timing and silent/muted triggers.
`MotionTests` checks bounded response and settling. `EditorTests` also checks
actual glyph pixels for isolated bus response and supported resize bounds.

Upstream source is preserved in `third_party/dub1`. Regenerate the instance-owned
C++ engine with `python3 tools/generate_engine.py`. The generated class is not
copyable: delay descriptors point into instance storage. The actual editor can be
captured using the `DubPreview` target and its `--capture` argument.

See `docs/VALIDATION.md` for the checks performed and audition limits.

## Credits and source

Upstream DUB-1 revision: `0945f5ba447ba9f836ac4759e4ebcb7772e47c16`.
Native port and UI: Pixel Records, 2026. DUB-1/AMB-1 DSP and this port are
GPL-3.0-only; see `LICENSE` and `third_party/dub1/LICENSING.md`. JUCE and its
dependencies retain their own notices and AGPLv3/commercial licensing terms;
the supplied corresponding source includes them. See `THIRD-PARTY-NOTICES.md`.
PXL Dub is independent of M-VAVE, Hügelton Instruments and the upstream authors.
