#include "Engine.generated.h"
#include <array>
#include <memory>
#include <iostream>
#include <cstdlib>
#include <cmath>
static void require(bool v,const char* m){if(!v){std::cerr<<m<<'\n';std::exit(1);}}
int main(){
    for(int active=-1;active<4;++active){
        auto e=std::make_unique<pxldub::Engine>();e->en_init();
        const int parameters[]{pxldub::P_CHORD,pxldub::P_BASS,pxldub::P_PINGS,pxldub::P_DRUMS};
        for(int p:parameters)e->en_set(p,0);
        for(int p:{pxldub::P_CRACKLE,pxldub::P_ECHO,pxldub::P_REVERB,pxldub::P_CLOUD,pxldub::P_EVOLVE,pxldub::P_MOTION})e->en_set(p,0);
        if(active>=0)e->en_set(parameters[active],80);
        e->en_play(1);std::array<int32_t,512> audio{};std::array<float,5> peak{};
        for(int block=0;block<1400;++block){e->en_render(audio.data(),256,3072);for(int i=0;i<5;++i){require(std::isfinite(e->visualPeak[i])&&e->visualPeak[i]>=0,"nonfinite layer meter");peak[i]=std::max(peak[i],e->visualPeak[i]);}}
        for(int i=0;i<4;++i)require(i==active?peak[i]>1e-4f:peak[i]<1e-7f,"layer meter does not isolate its own sound");
        require(peak[4]<1e-7f,"wet meter reacts with wet paths disabled");
    }
    auto e=std::make_unique<pxldub::Engine>();e->en_init();
    e->en_set(pxldub::P_PINGS,0);e->en_set(pxldub::P_BASS,0);e->en_set(pxldub::P_DRUMS,0);e->en_set(pxldub::P_CRACKLE,0);e->en_play(1);
    std::array<int32_t,512> audio{};
    for(int i=0;i<345;++i)e->en_render(audio.data(),256,3072);
    e->en_play(0);float tail=0;
    for(int i=0;i<172;++i){e->en_render(audio.data(),256,3072);tail=std::max(tail,e->visualPeak[4]);}
    require(tail>1e-5f,"wet meter stops while effect tails are audible");
    std::cout<<"Meters: silence, four isolated layers and wet tails passed\n";
}
