#include "PluginProcessor.h"
#include <iostream>
class App : public juce::JUCEApplication {
public:
    const juce::String getApplicationName() override { return "PXL Dub Preview"; }
    const juce::String getApplicationVersion() override { return "0.4.0"; }
    void initialise(const juce::String& args) override {
        processor=std::make_unique<DubProcessor>();window=std::make_unique<Window>();
        auto* editor=processor->createEditor();window->setContentOwned(editor,true);window->centreWithSize(1100,760);window->setVisible(true);
        if(args.contains("--verify")) {
            auto require=[this](bool condition,const char* message){if(!condition){std::cerr<<message<<'\n';setApplicationReturnValue(1);quit();}return condition;};
            if(!require(editor->findChildWithID("instrument-menu")!=nullptr,"instrument actions menu is missing"))return;
            if(!require(editor->findChildWithID("output-scope")!=nullptr,"output trace is missing"))return;
            auto* pages=dynamic_cast<juce::TabbedComponent*>(editor->findChildWithID("pages"));
            if(!require(pages && pages->getNumTabs()==6,"all six instrument pages must remain available"))return;
            for(const auto* id:DubProcessor::duckIDs)if(!require(pages->getTabContentComponent(5)->findChildWithID(id)!=nullptr,"individual duck control is missing"))return;
            auto* recovery=pages->getTabContentComponent(0)->findChildWithID("kick-duck-recovery");
            if(!require(recovery && recovery->findChildWithID("duck_release"),"sidechain recovery control is missing"))return;
            auto tick=[&] {processor->activity.visualSequence.fetch_add(1);juce::Thread::sleep(50);juce::Timer::callPendingTimersSynchronously();};
            auto checkGlyphs=[&](int tab,int bus,int expected,int count) {
                pages->setCurrentTabIndex(tab);auto* page=pages->getCurrentContentComponent();
                const auto before=page->createComponentSnapshot(page->getLocalBounds());
                processor->activity.buses[bus].store(.2f);
                for(int frame=0;frame<5;++frame)tick();
                const auto after=page->createComponentSnapshot(page->getLocalBounds());
                const int width=page->getWidth()/count;
                for(int i=0;i<count;++i){int changed=0;
                    for(int y=page->getHeight()-40;y<page->getHeight()-15;++y)for(int x=i*width+15;x<i*width+65;++x)
                        changed+=before.getPixelAt(x,y)!=after.getPixelAt(x,y);
                    if(!require(i==expected?changed>10:changed==0,"glyph does not isolate its assigned audio bus"))return false;
                }
                processor->activity.buses[bus].store(0);return true;
            };
            if(!checkGlyphs(0,0,1,4))return;
            // A newly created editor starts from the static etching, even after prior activity.
            window->setContentOwned(processor->createEditor(),true);editor=dynamic_cast<juce::AudioProcessorEditor*>(window->getContentComponent());
            pages=dynamic_cast<juce::TabbedComponent*>(editor->findChildWithID("pages"));
            if(!checkGlyphs(1,1,2,3))return;
            for(auto size:{juce::Point<int>{1040,760},juce::Point<int>{1100,760},juce::Point<int>{1500,1000}}) {
                editor->setSize(size.x,size.y);
                for(int i=0;i<pages->getNumTabs();++i) {
                    pages->setCurrentTabIndex(i);auto* page=pages->getCurrentContentComponent();
                    for(auto* child:page->getChildren())if(!require(page->getLocalBounds().contains(child->getBounds()),"page control clips at a supported editor size"))return;
                }
            }
            processor->setEngineValue(pxldub::P_CUTOFF,81);
            window->setContentOwned(processor->createEditor(),true);
            if(!require(processor->engineValue(pxldub::P_CUTOFF)==81,"editor recreation changed a sound parameter"))return;
            std::cout<<"Editor: controls, isolated Play/Voices glyph motion, five pages, resize bounds and recreation passed\n";
            quit();return;
        }
        if(args.contains("--capture")) {
            processor->setPlayHead(&host);processor->prepareToPlay(44100,256);
            for(int i=0;i<96;++i){juce::AudioBuffer<float> audio(2,256);juce::MidiBuffer midi;processor->processBlock(audio,midi);host.ppq+=256./44100.*122./60.;}
            for(int frame=0;frame<6;++frame){juce::AudioBuffer<float> audio(2,256);juce::MidiBuffer midi;processor->processBlock(audio,midi);host.ppq+=256./44100.*122./60.;juce::Thread::sleep(50);juce::Timer::callPendingTimersSynchronously();}
            auto capture=[editor](const juce::String& name) {
                auto file=juce::File::getCurrentWorkingDirectory().getChildFile(name);
                if(auto stream=file.createOutputStream()){stream->setPosition(0);stream->truncate();juce::PNGImageFormat().writeImageToStream(editor->createComponentSnapshot(editor->getLocalBounds(),true,1.f),*stream);}
            };
            capture("PXL-Dub-editor.png");
            if(auto* tabs=dynamic_cast<juce::TabbedComponent*>(editor->findChildWithID("pages"))) {
                for(int i=1;i<tabs->getNumTabs();++i){tabs->setCurrentTabIndex(i);capture("PXL-Dub-"+tabs->getTabNames()[i].toLowerCase()+".png");}
            }
            // Exercise editor construction/destruction and parameter attachments a second time.
            window->setContentOwned(processor->createEditor(),true);
            quit();
        }
    }
    void shutdown() override {window.reset();processor.reset();}
    struct Window : juce::DocumentWindow {
        Window():DocumentWindow("PXL Dub",juce::Colours::black,allButtons){setUsingNativeTitleBar(true);setResizable(true,true);}
        void closeButtonPressed() override {juce::JUCEApplication::getInstance()->systemRequestedQuit();}
    };
    std::unique_ptr<DubProcessor> processor;std::unique_ptr<Window> window;
    struct PreviewHost : juce::AudioPlayHead {
        double ppq=0;
        juce::Optional<PositionInfo> getPosition()const override{PositionInfo p;p.setIsPlaying(true);p.setBpm(122);p.setPpqPosition(ppq);return p;}
    } host;
};
START_JUCE_APPLICATION(App)
