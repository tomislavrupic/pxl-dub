#include "Engine.generated.h"
#include <array>
#include <memory>
#include <cmath>
#include <iostream>
#include <cstdlib>
using namespace pxldub;
static void require(bool v,const char* m){if(!v){std::cerr<<m<<'\n';std::exit(1);}}
static std::unique_ptr<Engine> setup(int depth) {
    auto e=std::make_unique<Engine>();e->en_init();e->nativeDucking=true;
    for(int p:{P_CHORD,P_PINGS,P_BASS,P_DRUMS,P_CRACKLE,P_ECHO,P_REVERB,P_CLOUD,P_MOTION,P_EVOLVE})e->apply(p,0);
    e->apply(P_DUCK,depth);return e;
}
static double energy(const std::array<int32_t,512>& a){double sum=0;for(auto x:a)sum+=(double)x*x;return sum;}
int main(){
    std::array<int32_t,512> dry{},ducked{};
    for(int layer=0;layer<6;++layer) {
        auto clean=setup(0), bypass=setup(100), full=setup(100), unrelated=setup(100);
        for(auto* e:{clean.get(),bypass.get(),full.get(),unrelated.get()}) {
            e->setLayerDuck(layer,e==bypass.get()?0.f:1.f);
            if(e==unrelated.get())e->setLayerDuck((layer+1)%6,0.f);
            e->apply(P_DRUMS,80);
            if(layer==5){e->apply(P_CHORD,80);e->apply(P_ECHO,70);e->apply(P_REVERB,70);e->stab_fire(1,0);for(int k=0;k<200;++k)e->en_render(dry.data(),256,3072);e->apply(P_CHORD,0);}
            else if(layer==0){e->apply(P_CHORD,80);e->stab_fire(1,0);}
            else if(layer==1){e->apply(P_PINGS,80);e->bell_voice(0,60,1,0);}
            else if(layer==2){e->apply(P_BASS,80);e->bass_hit(1);}
            else if(layer==3)e->drum_fire(1,1);
            else {e->apply(P_CRACKLE,80);e->cr_gate=1;}
            e->drum_fire(0,1);e->drum[0].on=0;e->en_render(dry.data(),256,3072);
        }
        std::array<int32_t,512> unaffected{},other{};
        clean->en_render(dry.data(),256,3072);bypass->en_render(unaffected.data(),256,3072);
        full->en_render(ducked.data(),256,3072);unrelated->en_render(other.data(),256,3072);
        require(energy(dry)>1e7,"individual duck test must be audible");
        require(std::abs(energy(unaffected)/energy(dry)-1)<.001,"zero layer amount failed to bypass ducking");
        require(other==ducked,"unrelated layer amount changed another layer");
        require(energy(ducked)<energy(dry)*.25,"full layer amount did not pump");
    }
    {
        auto e=setup(100);e->setLayerDuck(0,1);e->setLayerDuck(0,0);e->apply(P_CHORD,80);e->stab_fire(1,0);
        e->en_render(dry.data(),1,3072);require(e->layerDuck[0]>.9f&&e->layerDuck[0]<1,"automation did not ramp");
        for(int i=0;i<40;++i)e->en_render(dry.data(),256,3072);
        require(e->layerDuck[0]<.0001f,"automation failed to settle");
    }
    for(int p:{P_CHORD,P_PINGS,P_BASS,P_CRACKLE}) {
        auto a=setup(0),b=setup(100);
        for(auto* e:{a.get(),b.get()}) {
            e->apply(p,80);e->apply(P_DRUMS,80);e->drum_fire(0,1);e->drum[0].on=0;
            if(p==P_CHORD)e->stab_fire(1,0);
            if(p==P_PINGS)e->bell_voice(0,60,1,0);
            if(p==P_BASS)e->bass_hit(1);
            if(p==P_CRACKLE)e->cr_gate=1;
            e->en_render(dry.data(),256,3072);
        }
        a->en_render(dry.data(),256,3072);b->en_render(ducked.data(),256,3072);
        require(energy(dry)>1e7,"duck test must render audible layer");
        require(energy(ducked)<energy(dry)*.25,"kick did not duck a music/texture bus");
    }
    auto a=setup(0),b=setup(100);
    for(auto* e:{a.get(),b.get()}){e->apply(P_DRUMS,80);e->drum_fire(0,1);}
    a->en_render(dry.data(),256,3072);b->en_render(ducked.data(),256,3072);
    require(dry==ducked && energy(dry)>1e8,"kick ducks itself");
    {
        auto steady=setup(100);for(int i=0;i<6;++i)steady->setLayerDuck(i,0);
        steady->apply(P_DRUMS,80);steady->drum_fire(0,1);steady->en_render(dry.data(),256,3072);
        require(steady->visualReduction==0,"reduction display reports ducking when all layers are steady");
    }
    for(int target:{0,1}) {
        auto clean=setup(0),ducker=setup(100);
        for(auto* e:{clean.get(),ducker.get()}) {
            e->apply(P_DRUMS,80);
            if(target==0){e->apply(P_CHORD,80);e->apply(P_ECHO,70);e->apply(P_REVERB,70);e->stab_fire(1,0);for(int k=0;k<200;++k)e->en_render(dry.data(),256,3072);e->apply(P_CHORD,0);}
            else e->drum_fire(1,1);
            e->drum_fire(0,1);e->drum[0].on=0;e->en_render(dry.data(),256,3072);
        }
        clean->en_render(dry.data(),256,3072);ducker->en_render(ducked.data(),256,3072);
        require(energy(dry)>1e7 && energy(ducked)<energy(dry)*.25,"wet return or non-kick drum escaped ducking");
    }
    float remaining[2]{};int i=0;
    for(float release:{20.f,800.f}){
        auto e=setup(100);e->setDuckRelease(release);e->apply(P_DRUMS,80);e->drum_fire(0,1);
        for(int k=0;k<17;++k)e->en_render(dry.data(),256,3072);
        remaining[i++]=e->duck_x;
    }
    require(remaining[0]<.01f && remaining[1]>.8f,"recovery time did not change sidechain envelope");
    auto silent=setup(100);silent->en_play(1);float reduction=0;
    for(int k=0;k<1400;++k){silent->en_render(dry.data(),256,3072);reduction=std::max(reduction,silent->visualReduction);}
    require(reduction==0,"silent drums trigger ghost ducking");
    auto muted=setup(100);muted->apply(P_DRUMS,80);muted->mutes=EN_M_KICK;muted->en_play(1);
    for(int k=0;k<1400;++k){muted->en_render(dry.data(),256,3072);require(muted->visualReduction==0,"muted kick triggers ducking");}
    std::cout<<"Ducking: musical buses/vinyl, kick isolation, recovery, silent/muted kick passed\n";
}
