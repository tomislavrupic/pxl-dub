#include <cstdio>
extern "C" {void dub_init();void dub_piece(int);void dub_play(int);void dub_render();int* dub_audio();}
int main(int argc,char** argv){if(argc!=2)return 2;auto* file=std::fopen(argv[1],"wb");if(!file)return 3;dub_init();dub_piece(0);dub_play(1);for(int i=0;i<300;++i){dub_render();std::fwrite(dub_audio(),sizeof(int),128,file);}std::fclose(file);}
