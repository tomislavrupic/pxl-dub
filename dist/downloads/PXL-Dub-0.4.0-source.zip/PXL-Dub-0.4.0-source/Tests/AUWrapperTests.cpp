#include <AudioToolbox/AudioToolbox.h>
#include <CoreFoundation/CoreFoundation.h>
#include <CoreMIDI/CoreMIDI.h>
#include <cmath>
#include <cstdlib>
#include <iostream>
#include <string>
#include <vector>
static void check(bool v,const char* m){if(!v){std::cerr<<m<<'\n';std::exit(1);}}
static void status(OSStatus s,const char* m){if(s){std::cerr<<m<<": "<<s<<'\n';std::exit(1);}}
struct Host {double sample=0;bool playing=true;};
static OSStatus beat(void* context,Float64* position,Float64* tempo){auto& h=*(Host*)context;if(position)*position=h.sample/24000.;if(tempo)*tempo=120.;return noErr;}
static OSStatus transport(void* context,Boolean* play,Boolean* changed,Float64* sample,Boolean* cycling,Float64* start,Float64* end){auto& h=*(Host*)context;if(play)*play=h.playing;if(changed)*changed=false;if(sample)*sample=h.sample;if(cycling)*cycling=false;if(start)*start=0;if(end)*end=0;return noErr;}
static AudioUnitParameterID parameter(AudioUnit unit,const std::string& name){
    UInt32 bytes=0;status(AudioUnitGetPropertyInfo(unit,kAudioUnitProperty_ParameterList,kAudioUnitScope_Global,0,&bytes,nullptr),"parameter list");
    std::vector<AudioUnitParameterID> ids(bytes/sizeof(AudioUnitParameterID));status(AudioUnitGetProperty(unit,kAudioUnitProperty_ParameterList,kAudioUnitScope_Global,0,ids.data(),&bytes),"parameters");
    for(auto id:ids){AudioUnitParameterInfo info{};UInt32 n=sizeof(info);status(AudioUnitGetProperty(unit,kAudioUnitProperty_ParameterInfo,kAudioUnitScope_Global,id,&info,&n),"parameter info");char text[256]{};if(info.cfNameString)CFStringGetCString(info.cfNameString,text,sizeof(text),kCFStringEncodingUTF8);else std::snprintf(text,sizeof(text),"%s",info.name);bool found=name==text;if(info.flags&kAudioUnitParameterFlag_CFNameRelease)CFRelease(info.cfNameString);if(found)return id;}
    check(false,"AU parameter missing");return 0;
}
int main(int argc,char** argv){
    check(argc==2,"pass the AU component bundle path");
    auto url=CFURLCreateFromFileSystemRepresentation(nullptr,(const UInt8*)argv[1],(CFIndex)std::strlen(argv[1]),true);
    auto bundle=CFBundleCreate(nullptr,url);CFRelease(url);check(bundle&&CFBundleLoadExecutable(bundle),"cannot load AU bundle");
    auto factory=(AudioComponentFactoryFunction)CFBundleGetFunctionPointerForName(bundle,CFSTR("PXL_DubAUFactory"));check(factory,"AU factory missing");
    AudioComponentDescription description{'aumu','PxDb','Pxrc',0,0};
    auto component=AudioComponentRegister(&description,CFSTR("Pixel Records: PXL Dub test"),256,factory);check(component,"cannot register local AU factory");
    AudioUnit unit=nullptr;status(AudioComponentInstanceNew(component,&unit),"instantiate AU");
    Host host;HostCallbackInfo callbacks{};callbacks.hostUserData=&host;callbacks.beatAndTempoProc=beat;callbacks.transportStateProc=transport;
    status(AudioUnitSetProperty(unit,kAudioUnitProperty_HostCallbacks,kAudioUnitScope_Global,0,&callbacks,sizeof(callbacks)),"host callbacks");
    AudioStreamBasicDescription format{};format.mSampleRate=48000;format.mFormatID=kAudioFormatLinearPCM;format.mFormatFlags=kAudioFormatFlagsNativeFloatPacked|kAudioFormatFlagIsNonInterleaved;format.mBytesPerPacket=4;format.mFramesPerPacket=1;format.mBytesPerFrame=4;format.mChannelsPerFrame=2;format.mBitsPerChannel=32;
    status(AudioUnitSetProperty(unit,kAudioUnitProperty_StreamFormat,kAudioUnitScope_Output,0,&format,sizeof(format)),"stereo format");
    UInt32 maximum=512;status(AudioUnitSetProperty(unit,kAudioUnitProperty_MaximumFramesPerSlice,kAudioUnitScope_Global,0,&maximum,sizeof(maximum)),"max frames");
    status(AudioUnitInitialize(unit),"initialise AU");
    status(MusicDeviceMIDIEvent(unit,0x90,60,100,0),"AU accepts ordinary host MIDI");
    MIDIEventList events{};auto* packet=MIDIEventListInit(&events,kMIDIProtocol_1_0);
    UInt32 word=(0x2u<<28)|(0x90u<<16)|(60u<<8)|100u;
    MIDIEventListAdd(&events,sizeof(events),packet,0,1,&word);
    status(MusicDeviceMIDIEventList(unit,0,&events),"AU accepts host MIDI event lists");
    struct Buffers{UInt32 count;AudioBuffer data[2];} buffers{};float left[256]{},right[256]{};buffers.count=2;buffers.data[0]={1,sizeof(left),left};buffers.data[1]={1,sizeof(right),right};
    auto render=[&]{AudioTimeStamp stamp{};stamp.mSampleTime=host.sample;stamp.mFlags=kAudioTimeStampSampleTimeValid;AudioUnitRenderActionFlags flags=0;status(AudioUnitRender(unit,&flags,&stamp,0,256,(AudioBufferList*)&buffers),"render AU");host.sample+=256;double e=0;for(int i=0;i<256;++i){check(std::isfinite(left[i])&&std::isfinite(right[i]),"nonfinite AU audio");e+=left[i]*left[i]+right[i]*right[i];}return e;};
    double energy=0;for(int i=0;i<375;++i)energy+=render();check(energy>.01,"AU has no audio during host transport");
    auto cutoff=parameter(unit,"Cutoff");AudioUnitParameterValue before=0;status(AudioUnitGetParameter(unit,cutoff,kAudioUnitScope_Global,0,&before),"read cutoff");
    CFPropertyListRef saved=nullptr;UInt32 size=sizeof(saved);status(AudioUnitGetProperty(unit,kAudioUnitProperty_ClassInfo,kAudioUnitScope_Global,0,&saved,&size),"save AU state");
    status(AudioUnitSetParameter(unit,cutoff,kAudioUnitScope_Global,0,.1f,0),"change cutoff");
    status(AudioUnitSetProperty(unit,kAudioUnitProperty_ClassInfo,kAudioUnitScope_Global,0,&saved,sizeof(saved)),"restore AU state");CFRelease(saved);
    AudioUnitParameterValue after=0;status(AudioUnitGetParameter(unit,cutoff,kAudioUnitScope_Global,0,&after),"read recalled cutoff");check(std::abs(before-after)<1e-5,"AU state recall failed");
    host.playing=false;double tails=0;for(int i=0;i<188;++i)tails+=render();check(tails>1e-7,"AU stop abruptly cut all tails");
    for(int i=0;i<11250;++i)render();double resting=0;for(int i=0;i<188;++i)resting+=render();check(resting<1e-6,"AU continued generating after stop");
    status(AudioUnitUninitialize(unit),"uninitialise AU");status(AudioComponentInstanceDispose(unit),"dispose AU");
    CFRelease(bundle);std::cout<<"AU wrapper: local factory loads, 48 kHz stereo audio, state recall, stop tails and eventual silence pass\n";
}
