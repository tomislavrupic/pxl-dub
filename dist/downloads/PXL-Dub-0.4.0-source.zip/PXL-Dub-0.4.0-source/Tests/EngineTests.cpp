#include "Engine.generated.h"
#include <memory>
#include <vector>
#include <iostream>
#include <cstdlib>
extern "C" {
void en_init();
void en_set(int, int);
void en_seed(uint32_t);
void en_render(int32_t*, uint32_t, uint32_t);
void en_play(int);
void en_pool(uint32_t);
void en_regrow();
void en_freeze(int);
void en_midi_out(uint32_t, uint32_t, uint32_t) {}
}
static void require(bool v, const char* m) { if (!v) { std::cerr << m << '\n'; std::exit(1); } }
int main() {
    auto a = std::make_unique<pxldub::Engine>();
    auto b = std::make_unique<pxldub::Engine>();
    a->en_init(); b->en_init(); en_init();
    a->en_play(1); b->en_play(1); en_play(1);
    double energy=0;
    std::vector<int32_t> original(512), ported(512), other(512);
    for (int piece = 0; piece < 8; ++piece) {
        int16_t recipe[pxldub::P_NPARAMS]; uint16_t pool;
        a->en_piece(piece, recipe, &pool);
        for (int p = 0; p < pxldub::P_NPARAMS; ++p) { a->en_set(p, recipe[p]); en_set(p, recipe[p]); }
        a->en_pool(pool); en_pool(pool); a->en_seed(123); en_seed(123);
        a->en_regrow(); en_regrow();
        for (int block = 0; block < 500; ++block) {
            if (block == 200) { a->en_freeze(1); en_freeze(1); }
            if (block == 300) { a->en_freeze(0); en_freeze(0); }
            a->en_render(ported.data(), 256, 3072);
            // An unrelated instance must not disturb a's RNG, oscillators or delay buffers.
            b->en_set(pxldub::P_ROOT, (block + piece) % 12);
            b->en_render(other.data(), 256, 3072);
            en_render(original.data(), 256, 3072);
            require(original == ported, "ported engine differs from upstream render");
            for(auto sample:ported)energy+=(double)sample*sample;
        }
    }
    require(energy>1e12,"parity test must compare audible music");
    uint8_t loops[EN_PINGS_N];
    a->en_pings_get(loops);
    b->en_pings(loops); b->en_render(other.data(), 1, 0);
    uint8_t restored[EN_PINGS_N]; b->en_pings_get(restored);
    for (int i = 0; i < EN_PINGS_N; ++i) require(loops[i] == restored[i], "ping loop recall differs");
    std::cout << "Engine: 8 presets, exact upstream parity, instance isolation and ping recall passed\n";
}
