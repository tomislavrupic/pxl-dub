#include "PluginProcessor.h"
#include <iostream>
#include <cstdlib>
#include <cmath>
#include <new>
static thread_local bool inAudioCallback=false;
static thread_local size_t audioAllocations=0;
void* operator new(std::size_t size) { if(inAudioCallback)++audioAllocations;if(auto* p=std::malloc(size?size:1))return p;throw std::bad_alloc(); }
void* operator new[](std::size_t size) { return ::operator new(size); }
void operator delete(void* p) noexcept { std::free(p); }
void operator delete[](void* p) noexcept { std::free(p); }
static void require(bool v, const char* message) { if (!v) { std::cerr << message << '\n'; std::exit(1); } }
struct Host : juce::AudioPlayHead {
    double bpm = 122, ppq = 0; bool playing = true;
    juce::Optional<PositionInfo> getPosition() const override {
        PositionInfo p; p.setBpm(bpm); p.setPpqPosition(ppq); p.setIsPlaying(playing); return p;
    }
};
static double render(DubProcessor& p, Host& host, double rate, int size, int blocks) {
    double energy = 0;
    for (int k = 0; k < blocks; ++k) {
        juce::AudioBuffer<float> b(2, size); juce::MidiBuffer midi;
        inAudioCallback=true;p.processBlock(b, midi);inAudioCallback=false;
        require(audioAllocations==0,"audio callback allocated memory");
        for (int c = 0; c < 2; ++c) for (int i = 0; i < size; ++i) {
            float x = b.getSample(c, i); require(std::isfinite(x) && std::abs(x) <= 1.01f, "invalid output sample"); energy += x*x;
        }
        if (host.playing) host.ppq += size / rate * host.bpm / 60.;
    }
    return energy;
}
int main(int argc, char** argv) {
    juce::ScopedJuceInitialiser_GUI init;
    {
        DubProcessor status;
        const std::array<std::array<int,4>,5> chords{{{{60,63,66,72}},{{60,64,68,72}},{{60,62,67,72}},{{60,65,67,72}},{{60,63,67,70}}}};
        const char* names[]{"Cdim","Caug","Csus2","Csus4","Cm7"};
        for(size_t i=0;i<chords.size();++i){status.activity.root.store(0);for(int j=0;j<4;++j)status.activity.chord[j].store(chords[i][j]);require(status.currentChordName()==names[i],"footer chord quality is incorrect");}
    }
    for (double rate : {44100., 48000., 96000.}) for (int size : {1, 17, 128, 512, 2048}) {
        DubProcessor p; Host host; p.setPlayHead(&host); p.prepareToPlay(rate, size);
        p.setEngineValue(pxldub::P_MOTION, 0); p.setEngineValue(pxldub::P_CRACKLE, 0);
        require(render(p, host, rate, size, (int)(rate / size * 1.2)) > .01, "no instrument audio");
        double traceEnergy=0;for(auto& sample:p.activity.scope){float x=sample.load();require(std::isfinite(x),"nonfinite output trace");traceEnergy+=x*x;}require(traceEnergy>1e-8,"output trace did not receive live engine audio");
        require(p.activity.steps.load() >= 9 && p.activity.steps.load() <= 11, "host clock drift");
        host.playing = false; render(p, host, rate, size, 5); require(!p.activity.running.load(), "host stop ignored");
        host.playing = true; host.ppq = 0; render(p, host, rate, size, 1);
        require(p.activity.steps.load() <= 2, "restart did not reset phrase");
        host.ppq += 40; render(p, host, rate, size, 1);
        require(p.activity.steps.load() <= 2, "seek did not reset phrase");
    }
    for (double bpm : {35., 90., 122.5, 200., 320.}) {
        DubProcessor p; Host host; host.bpm = bpm; p.setPlayHead(&host); p.prepareToPlay(48000, 128);
        render(p, host, 48000, 128, 750);
        require(std::abs((double)p.activity.steps.load() - 2.*bpm/15.) < 2, "tempo outside hardware range incorrect");
        require(p.engineValue(pxldub::P_TEMPO) == 122, "host tempo overwrote internal tempo");
    }
    {
        DubProcessor seeking;Host h;h.bpm=320;seeking.setPlayHead(&h);seeking.prepareToPlay(48000,2048);
        render(seeking,h,48000,2048,20);h.ppq-=.25;render(seeking,h,48000,2048,1);
        require(seeking.activity.steps.load()<=2,"short backward loop was ignored at large buffer size");
    }
    {
        DubProcessor musical;Host h;musical.setPlayHead(&h);musical.prepareToPlay(44100,256);
        musical.requestRegrow();render(musical,h,44100,256,20);const auto loops=musical.pingSnapshot();
        musical.requestPanic();render(musical,h,44100,256,1);require(loops==musical.pingSnapshot(),"panic changed musical ping loops");
        musical.prepareToPlay(48000,128);render(musical,h,48000,128,1);require(loops==musical.pingSnapshot(),"sample-rate reprepare changed musical ping loops");
    }
    DubProcessor p; Host host; p.setPlayHead(&host); p.prepareToPlay(44100, 256);
    p.loadPiece(3); p.setEngineValue(pxldub::P_CUTOFF, 73); p.setEngineValue(pxldub::P_DPAT4, -12345);
    p.setValue("duck_release",425);
    p.setValue("duck_chord",23);p.setValue("duck_space",0);
    p.setValue("scale", 0x589); render(p, host, 44100, 256, 60);
    juce::MemoryBlock saved; p.getStateInformation(saved);
    DubProcessor suspended; suspended.setStateInformation(saved.getData(), (int)saved.getSize());
    juce::MemoryBlock suspendedSaved;suspended.getStateInformation(suspendedSaved);
    auto savedXml=juce::AudioProcessor::getXmlFromBinary(saved.getData(),(int)saved.getSize());
    auto suspendedXml=juce::AudioProcessor::getXmlFromBinary(suspendedSaved.getData(),(int)suspendedSaved.getSize());
    require(savedXml->getStringAttribute("pings")==suspendedXml->getStringAttribute("pings"),"saving suspended restored state lost ping loops");
    require(p.state.getParameter("piece")==nullptr,"piece metadata must not advertise unsupported automation");
    {
        DubProcessor scales;Host h;scales.setPlayHead(&h);scales.prepareToPlay(44100,256);
        require(scales.value("scale")==0,"default scale must follow automated mode");
        scales.setEngineValue(pxldub::P_MODE,pxldub::MODE_AEOLIAN);render(scales,h,44100,256,1);
        require(scales.scaleMask()==pxldub::modePool(pxldub::MODE_AEOLIAN),"mode automation did not change scale");
        scales.setValue("scale",0x589);scales.setEngineValue(pxldub::P_MODE,pxldub::MODE_IONIAN);render(scales,h,44100,256,1);
        require(scales.scaleMask()==0x589,"mode automation overwrote a custom scale");
        DubProcessor modeDriven,maskDriven;Host modeHost,maskHost;
        modeDriven.setPlayHead(&modeHost);maskDriven.setPlayHead(&maskHost);modeDriven.prepareToPlay(44100,256);maskDriven.prepareToPlay(44100,256);
        modeDriven.setEngineValue(pxldub::P_MODE,pxldub::MODE_IONIAN);maskDriven.setValue("scale",(float)pxldub::modePool(pxldub::MODE_IONIAN));
        for(int i=0;i<100;++i){juce::AudioBuffer<float> a(2,256),b(2,256);juce::MidiBuffer ma,mb;modeDriven.processBlock(a,ma);maskDriven.processBlock(b,mb);for(int c=0;c<2;++c)for(int j=0;j<256;++j)require(a.getSample(c,j)==b.getSample(c,j),"automated mode did not reach the sound engine");modeHost.ppq+=256./44100.*122./60.;maskHost.ppq=modeHost.ppq;}
    }
    DubProcessor restored; Host host2; restored.setPlayHead(&host2); restored.setStateInformation(saved.getData(), (int)saved.getSize()); restored.prepareToPlay(44100, 256);
    require(restored.engineValue(pxldub::P_CUTOFF) == 73 && restored.engineValue(pxldub::P_DPAT4) == -12345, "parameter recall failed");
    require(restored.value("scale") == 0x589 && restored.getCurrentProgram() == 3, "scale/preset recall failed");
    require(restored.value("duck_release")==425,"sidechain recovery recall failed");
    require(restored.value("duck_chord")==23 && restored.value("duck_space")==0,"individual duck recall failed");
    {
        auto oldTree=juce::ValueTree::fromXml(*savedXml);
        oldTree.removeChild(oldTree.getChildWithProperty("id","duck_release"),nullptr);
        for(const auto* id:{"duck_chord","duck_pings","duck_bass","duck_percussion","duck_vinyl","duck_space"})oldTree.removeChild(oldTree.getChildWithProperty("id",id),nullptr);
        juce::MemoryBlock oldState;if(auto xml=oldTree.createXml())juce::AudioProcessor::copyXmlToBinary(*xml,oldState);
        DubProcessor legacy;legacy.setValue("duck_release",800);legacy.setStateInformation(oldState.getData(),(int)oldState.getSize());
        require(legacy.value("duck_release")==130,"old session inherited an unrelated recovery setting");
        require(legacy.value("duck_chord")==100&&legacy.value("duck_space")==100,"old session lost compatible layer duck defaults");
    }
    render(restored, host2, 44100, 256, 1);
    require(p.pingSnapshot() == restored.pingSnapshot(), "processor ping loop recall failed");
    p.setValue("sync", 0); p.setValue("run", 0); render(p, host, 44100, 256, 1);
    require(!p.activity.running.load(), "internal run off ignored");
    p.setValue("run", 1); render(p, host, 44100, 256, 1); require(p.activity.running.load(), "internal run ignored");
    p.requestPanic(); require(render(p, host, 44100, 256, 8) < 1e-8, "panic did not silence output");
    p.setValue("run",0);render(p,host,44100,256,1);p.setValue("run",1);
    for (int i = 0; i < 8; ++i) { p.loadPiece(i);require(render(p, host, 44100, 256, 80)>.01,"preset switch failed to produce audio");require(p.getCurrentProgram()==i,"preset selection metadata incorrect"); }
    if (argc > 1) {
        DubProcessor demo; Host h; demo.setPlayHead(&h); demo.prepareToPlay(48000, 256);
        std::unique_ptr<juce::OutputStream> stream = juce::File(juce::String(argv[1])).createOutputStream();
        juce::WavAudioFormat format;
        auto writer=format.createWriterFor(stream,juce::AudioFormatWriterOptions{}.withSampleRate(48000).withNumChannels(2).withBitsPerSample(24));
        require(writer != nullptr, "could not create demo WAV");
        for (int k = 0; k < 48000*24/256; ++k) {
            juce::AudioBuffer<float> b(2,256); juce::MidiBuffer midi;
            if (k == 2250) demo.setValue("hold",1);
            if (k == 3000) demo.setValue("hold",0);
            if (k == 3750) h.playing=false;
            demo.processBlock(b,midi); writer->writeFromAudioSampleBuffer(b,0,256);
            h.ppq += 256./48000.*h.bpm/60.;
        }
    }
    std::cout << "Processor: audio, rates/blocks, transport, tempo, preset/state/pings and panic passed\n";
}
