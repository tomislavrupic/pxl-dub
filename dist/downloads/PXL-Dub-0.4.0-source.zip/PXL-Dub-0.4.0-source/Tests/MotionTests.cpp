#include "SignalMotion.h"
#include <cmath>
#include <cstdlib>
#include <iostream>
static void require(bool v,const char* m){if(!v){std::cerr<<m<<'\n';std::exit(1);}}
int main(){
    dubui::SignalFeed feed;
    require(feed.advance(1,.04f),"new audio block considered stale");
    require(!feed.advance(1,.3f),"suspended audio keeps graphics alive");
    require(feed.advance(2,.04f),"resumed audio does not wake graphics");
    dubui::SignalMotion m;
    for(int i=0;i<240;++i)m.advance(0,1.f/24);
    require(m.amount==0 && m.phase==0,"silent glyph moves at idle");
    for(int i=0;i<1000;++i){m.advance(i%2?.8f:.01f,1.f/24);require(m.amount>=0&&m.amount<=1&&std::isfinite(m.phase),"motion exceeds its range");}
    require(m.amount>.1f,"glyph does not respond to signal");
    for(int i=0;i<240;++i)m.advance(0,1.f/24);
    require(m.amount==0&&m.phase==0,"glyph does not settle to static etching");
    m.advance(INFINITY,1.f/24);m.advance(NAN,1.f/24);require(std::isfinite(m.amount),"bad signal poisons UI");
    std::cout<<"Motion: bounded response, silence, settling and invalid-input handling passed\n";
}
